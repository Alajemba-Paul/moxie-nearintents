import type { PerpsKlineInterval } from '@polymarket/bindings/perps';
import type {
  CommentsEvent,
  CryptoPriceEvent,
  CryptoPricesBinanceEvent,
  CryptoPricesChainlinkEvent,
  CryptoPricesChainlinkTwapEvent,
  CryptoPricesChainlinkTwapSixtyEvent,
  CryptoPricesChainlinkTwapThirtyEvent,
  CryptoPricesChainlinkTwapTopic,
  CryptoPricesChainlinkTwapWindowSeconds,
  CryptoPricesEvent,
  CryptoPricesTopic,
  CryptoTwapPriceEvent,
  CustomMarketEvent,
  EquityPriceEvent,
  EquityPricesEvent,
  EquityPricesTopic,
  EquityTwapPriceEvent,
  MarketEvent,
  PerpsBboEvent,
  PerpsBookEvent,
  PerpsCandleEvent,
  PerpsMarketDataEvent,
  PerpsStatisticEvent,
  PerpsTickerEvent,
  PerpsTradeEvent,
  PriceProvider,
  PriceSource,
  SportsEvent,
  StandardMarketEvent,
  UserEvent,
} from '@polymarket/bindings/subscriptions';
import { invariant, type Prettify } from '@polymarket/types';
import merge from 'it-merge';
import { z } from 'zod';
import type {
  BaseClient,
  BasePublicClient,
  BaseSecureClient,
} from '../clients';
import {
  ConnectionLostError,
  makeErrorGuard,
  RequestRejectedError,
  TransportError,
  UserInputError,
} from '../errors';
import { parseUserInput } from '../input';
import { parsePriceSubscription } from './price-subscriptions';

export type {
  CommentsEvent,
  CryptoPriceEvent,
  CryptoPriceSnapshotEvent,
  CryptoPricesBinanceEvent,
  CryptoPricesChainlinkEvent,
  CryptoPricesChainlinkTwapEvent,
  CryptoPricesChainlinkTwapSixtyEvent,
  CryptoPricesChainlinkTwapThirtyEvent,
  CryptoPricesChainlinkTwapWindowSeconds,
  CryptoPricesEvent,
  CryptoTwapPriceEvent,
  CryptoTwapPriceSnapshotEvent,
  EquityPriceEvent,
  EquityPricesEvent,
  EquityTwapPriceEvent,
  EquityTwapPriceSnapshotEvent,
  PriceSource,
} from '@polymarket/bindings/subscriptions';
export {
  EquityMarketStatus,
  KnownPriceSource,
  PriceProvider,
} from '@polymarket/bindings/subscriptions';
// Event types — re-exported from bindings for consumer convenience.
/** @experimental This API may change in a breaking way in any release, including patch releases. */
export type {
  CustomMarketEvent,
  MarketEvent,
  PerpsBboEvent,
  PerpsBookEvent,
  PerpsCandleEvent,
  PerpsMarketDataEvent,
  PerpsStatisticEvent,
  PerpsTickerEvent,
  PerpsTradeEvent,
  SportsEvent,
  StandardMarketEvent,
  UserEvent,
};

// Event `type` discriminants derived from bindings events.
export type MarketEventType = MarketEvent['type'];
export type UserEventType = UserEvent['type'];
export type SportsEventType = SportsEvent['type'];
export type CommentsEventType = CommentsEvent['type'];
export type CryptoPricesEventType = CryptoPricesEvent['type'];
export type EquityPricesEventType = EquityPricesEvent['type'];
/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsMarketDataEventType = PerpsMarketDataEvent['type'];

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsStreamingCandleInterval = Exclude<
  PerpsKlineInterval,
  PerpsKlineInterval.OneSecond
>;

type PerpsInstrumentIdInput = number;

// Subscription specs.
export type MarketSubscription =
  | {
      topic: 'market';
      /** Asset identifiers whose market events should be delivered. */
      assetIds: readonly string[];
      tokenIds?: never;

      /**
       * When `true`, the server additionally emits `MarketBestBidAskEvent`,
       * `NewMarketEvent`, and `MarketResolvedEvent`.
       */
      customFeatureEnabled?: boolean;
    }
  | {
      topic: 'market';
      assetIds?: never;
      /** @deprecated Use `assetIds`. */
      tokenIds: readonly string[];

      /**
       * When `true`, the server additionally emits `MarketBestBidAskEvent`,
       * `NewMarketEvent`, and `MarketResolvedEvent`.
       */
      customFeatureEnabled?: boolean;
    };

export type UserSubscription = {
  topic: 'user';
  markets?: readonly string[];
};

export type SportsSubscription = {
  topic: 'sports';
};

/**
 * @deprecated The comments stream is being discontinued.
 * Use `client.listComments()` to retrieve comments. This method does not
 * provide live comment or reaction events.
 *
 * @example
 * ```ts
 * const pages = client.listComments({
 *   parentEntityId: '123',
 *   parentEntityType: CommentParentEntityType.Event,
 *   pageSize: 20,
 * });
 * const page = await pages.firstPage();
 *
 * for (const comment of page.items) {
 *   console.log(comment);
 * }
 * ```
 */
export type CommentsSubscription = {
  topic: 'comments';
  types?: readonly CommentsEventType[];
  parentEntityId?: number;
  parentEntityType?: 'Event' | 'Market';
};

/**
 * @deprecated Use `prices.crypto` with a secure client and explicit canonical
 * USD symbols. Events include history snapshots. Removal is planned one month
 * after the 0.11.0 release.
 *
 * Binance USDT prices and PolyBolt USD prices have different quote currencies
 * and feed sources; this is not a like-for-like replacement. Chainlink spot
 * consumers must also assess the change in feed source.
 *
 * @example
 * ```ts
 * // Before: Chainlink USD or Binance USDT prices.
 * const legacyPrices = await publicClient.subscribe([
 *   { topic: 'prices.crypto.chainlink', symbols: ['btc/usd'] },
 *   { topic: 'prices.crypto.binance', symbols: ['btcusdt'] },
 * ]);
 *
 * // After: secureClient is already authenticated; choose USD prices explicitly.
 * const prices = await secureClient.subscribe([
 *   { topic: 'prices.crypto', symbols: ['btcusd'] },
 * ]);
 * for await (const event of prices) {
 *   if (event.type !== 'update') continue;
 *   console.log(event.payload.symbol, event.payload.value);
 * }
 * ```
 */
export type CryptoPricesSubscription = {
  topic: CryptoPricesTopic;
  symbols?: readonly string[];
};

/**
 * @deprecated Use `prices.crypto.twap` with a secure client and explicit
 * canonical USD symbols. The replacement provides 60-second TWAP prices and
 * history snapshots. There is no replacement for the 30-second window.
 * Removal is planned one month after the 0.11.0 release.
 *
 * @example
 * ```ts
 * // Before
 * const legacyPrices = await publicClient.subscribe([
 *   {
 *     topic: 'prices.crypto.chainlink.twap',
 *     symbols: ['btc/usd'],
 *     windowSeconds: 60,
 *   },
 * ]);
 *
 * // After: secureClient is already authenticated.
 * const prices = await secureClient.subscribe([
 *   { topic: 'prices.crypto.twap', symbols: ['btcusd'] },
 * ]);
 * for await (const event of prices) {
 *   if (event.type !== 'update') continue;
 *   console.log(event.payload.symbol, event.payload.value);
 * }
 * ```
 */
export type CryptoPricesChainlinkTwapSubscription = {
  topic: CryptoPricesChainlinkTwapTopic;
  windowSeconds: CryptoPricesChainlinkTwapWindowSeconds;
  symbols?: readonly string[];
};

/**
 * @deprecated Use `prices.equity` with a secure client. The existing symbol
 * and event-type filters remain available. Removal is planned one month after
 * the 0.11.0 release.
 *
 * @example
 * ```ts
 * // Before
 * const legacyPrices = await publicClient.subscribe([
 *   { topic: 'prices.equity.pyth', symbol: 'aapl', types: ['update'] },
 * ]);
 *
 * // After: secureClient is already authenticated.
 * const prices = await secureClient.subscribe([
 *   { topic: 'prices.equity', symbol: 'aapl', types: ['update'] },
 * ]);
 * ```
 */
export type EquityPricesSubscription = {
  topic: EquityPricesTopic;
  symbol: string;
  types?: readonly EquityPricesEventType[];
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsTradesSubscription = {
  topic: 'perps.trades';
  instrumentId: PerpsInstrumentIdInput;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsBboSubscription = {
  topic: 'perps.bbo';
  instrumentId: PerpsInstrumentIdInput;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsBookSubscription = {
  topic: 'perps.book';
  instrumentId: PerpsInstrumentIdInput;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsCandlesSubscription = {
  topic: 'perps.candles';
  instrumentId: PerpsInstrumentIdInput;
  interval: PerpsStreamingCandleInterval;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsTickersSubscription = {
  topic: 'perps.tickers';
  instrumentId?: PerpsInstrumentIdInput;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsStatisticsSubscription = {
  topic: 'perps.statistics';
  instrumentId?: PerpsInstrumentIdInput;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsMarketDataSubscription =
  | PerpsTradesSubscription
  | PerpsBboSubscription
  | PerpsBookSubscription
  | PerpsCandlesSubscription
  | PerpsTickersSubscription
  | PerpsStatisticsSubscription;

export type PublicSubscriptionSpec =
  | MarketSubscription
  | SportsSubscription
  | CommentsSubscription
  | CryptoPricesSubscription
  | CryptoPricesChainlinkTwapSubscription
  | EquityPricesSubscription
  | PerpsMarketDataSubscription;

/** Confirmation of one price subscription, refreshed after every reconnect. */
export type PriceSubscriptionConfirmation = {
  /** Canonical lowercase symbol the confirmation is for. */
  symbol: string;
  /**
   * The provider actually served, including fallback. Undefined when the
   * server does not confirm provider selection; never inferred from the pin.
   */
  provider?: PriceSource;
};

/**
 * Symbol-filtered cryptocurrency updates and recent history. Requires a secure
 * client and canonical lowercase USD pairs such as `btcusd`.
 * Slash-separated symbols and USDT pairs are rejected.
 */
export type CryptoPriceSubscription = {
  topic: 'prices.crypto';
  symbols: readonly string[];
  /** Requested vendor. Omit to follow the default; an unavailable pin may fall back. */
  provider?: PriceProvider;
  /**
   * Called once per symbol on acceptance and every reconnect, or immediately
   * when joining an accepted subscription. A thrown error or rejected promise
   * ends this handle with TransportError.
   */
  onSubscribed?: (
    confirmation: PriceSubscriptionConfirmation,
  ) => void | Promise<void>;
};
/**
 * 60-second time-weighted prices and recent history. Requires a secure client
 * and canonical lowercase USD pairs such as `btcusd`. The window is fixed;
 * returned events include `windowSeconds: 60` as metadata.
 */
export type CryptoTwapPriceSubscription = {
  topic: 'prices.crypto.twap';
  symbols: readonly string[];
  /** Requested vendor. Omit to follow the default; an unavailable pin may fall back. */
  provider?: PriceProvider;
  /**
   * Called once per symbol on acceptance and every reconnect, or immediately
   * when joining an accepted subscription. A thrown error or rejected promise
   * ends this handle with TransportError.
   */
  onSubscribed?: (
    confirmation: PriceSubscriptionConfirmation,
  ) => void | Promise<void>;
};
/** Equity updates and recent history. Requires a secure client. */
export type EquityPriceSubscription = {
  topic: 'prices.equity';
  symbol: string;
  types?: readonly ('subscribe' | 'update')[];
  /** Requested vendor. Omit to follow the default; an unavailable pin may fall back. */
  provider?: PriceProvider;
  /**
   * Called once per symbol on acceptance and every reconnect, or immediately
   * when joining an accepted subscription. A thrown error or rejected promise
   * ends this handle with TransportError.
   */
  onSubscribed?: (
    confirmation: PriceSubscriptionConfirmation,
  ) => void | Promise<void>;
};
/**
 * 60-second time-weighted equity prices and recent history. Requires a secure
 * client. Symbols such as `eurusd` and `usdjpy` are case-insensitive; prices
 * use the symbol's quote currency. Returned events include `windowSeconds: 60`.
 */
export type EquityTwapPriceSubscription = {
  topic: 'prices.equity.twap';
  symbol: string;
  /** Requested vendor. Omit to follow the default; an unavailable pin may fall back. */
  provider?: PriceProvider;
  /**
   * Called once per symbol on acceptance and every reconnect, or immediately
   * when joining an accepted subscription. A thrown error or rejected promise
   * ends this handle with TransportError.
   */
  onSubscribed?: (
    confirmation: PriceSubscriptionConfirmation,
  ) => void | Promise<void>;
};
export type PriceSubscription =
  | CryptoPriceSubscription
  | CryptoTwapPriceSubscription
  | EquityPriceSubscription
  | EquityTwapPriceSubscription;
export type SecureSubscriptionSpec =
  | PublicSubscriptionSpec
  | UserSubscription
  | PriceSubscription;

// Event unions, aligned with subscription specs.
export type PublicRealtimeEvent =
  | MarketEvent
  | SportsEvent
  | CommentsEvent
  | CryptoPricesEvent
  | EquityPricesEvent
  | PerpsMarketDataEvent;

export type SecureRealtimeEvent =
  | PublicRealtimeEvent
  | UserEvent
  | CryptoPriceEvent
  | CryptoTwapPriceEvent
  | EquityPriceEvent
  | EquityTwapPriceEvent;

// Topics derived from event unions so bindings remain the single source of
// truth for topic literals.
export type PublicRealtimeTopic = Prettify<PublicRealtimeEvent['topic']>;
export type SecureRealtimeTopic = Prettify<SecureRealtimeEvent['topic']>;

// Spec-to-event mapping keyed by the shared `topic` discriminant. Each simple
// topic resolves to a named event type so hover shows the alias rather than an
// expanded structural shape. Market subscriptions are handled separately
// because `customFeatureEnabled` contributes to the event union.
//
// Relies on `subscribe` declaring `TSubscriptions` with the `const` modifier
// so that literal topics survive inference from object literals.
type EventByTopic = {
  'prices.crypto': CryptoPriceEvent;
  'prices.crypto.twap': CryptoTwapPriceEvent;
  'prices.equity': EquityPriceEvent;
  'prices.equity.twap': EquityTwapPriceEvent;
  comments: CommentsEvent;
  'prices.crypto.binance': CryptoPricesBinanceEvent;
  'prices.crypto.chainlink': CryptoPricesChainlinkEvent;
  'prices.crypto.chainlink.twap': CryptoPricesChainlinkTwapEvent;
  'prices.equity.pyth': EquityPricesEvent;
  user: UserEvent;
  sports: SportsEvent;
  'perps.trades': PerpsTradeEvent;
  'perps.bbo': PerpsBboEvent;
  'perps.book': PerpsBookEvent;
  'perps.candles': PerpsCandleEvent;
  'perps.tickers': PerpsTickerEvent;
  'perps.statistics': PerpsStatisticEvent;
};

type EventForMarketSubscription<TSpec extends MarketSubscription> =
  'customFeatureEnabled' extends keyof TSpec
    ? true extends TSpec['customFeatureEnabled']
      ? MarketEvent
      : StandardMarketEvent
    : StandardMarketEvent;

type EventForCryptoPricesChainlinkTwapSubscription<
  TSpec extends CryptoPricesChainlinkTwapSubscription,
> = TSpec extends { windowSeconds: 30 }
  ? CryptoPricesChainlinkTwapThirtyEvent
  : TSpec extends { windowSeconds: 60 }
    ? CryptoPricesChainlinkTwapSixtyEvent
    : CryptoPricesChainlinkTwapEvent;

export type EventForSubscriptionSpec<TSpec extends SecureSubscriptionSpec> =
  TSpec extends MarketSubscription
    ? EventForMarketSubscription<TSpec>
    : TSpec extends CryptoPricesChainlinkTwapSubscription
      ? EventForCryptoPricesChainlinkTwapSubscription<TSpec>
      : TSpec extends { topic: infer TTopic extends keyof EventByTopic }
        ? EventByTopic[TTopic]
        : never;

export type EventForSubscriptionSpecs<
  TSubscriptions extends readonly SecureSubscriptionSpec[],
> = EventForSubscriptionSpec<TSubscriptions[number]>;

export type SubscriptionHandle<TEvent> = {
  /**
   * Closes the subscription. Idempotent: subsequent calls resolve without
   * effect. Best-effort — errors from the first call propagate, later calls
   * are no-ops.
   */
  close(): Promise<void>;
} & AsyncIterable<TEvent>;

export type SubscribeError =
  | TransportError
  | UserInputError
  | RequestRejectedError
  | ConnectionLostError;
export const SubscribeError = makeErrorGuard(
  TransportError,
  UserInputError,
  RequestRejectedError,
  ConnectionLostError,
);

enum SubscriptionTopic {
  Market = 'market',
  User = 'user',
  Sports = 'sports',
  Crypto = 'prices.crypto',
  Twap = 'prices.crypto.twap',
  Equity = 'prices.equity',
  EquityTwap = 'prices.equity.twap',
  Comments = 'comments',
  LegacyBinance = 'prices.crypto.binance',
  LegacyChainlink = 'prices.crypto.chainlink',
  LegacyTwap = 'prices.crypto.chainlink.twap',
  LegacyEquity = 'prices.equity.pyth',
  PerpsTrades = 'perps.trades',
  PerpsBbo = 'perps.bbo',
  PerpsBook = 'perps.book',
  PerpsCandles = 'perps.candles',
  PerpsTickers = 'perps.tickers',
  PerpsStatistics = 'perps.statistics',
}
const SubscriptionTopicSchema = z.object({ topic: z.enum(SubscriptionTopic) });
const LegacyTwapSubscriptionSchema = z.object({
  topic: z.literal('prices.crypto.chainlink.twap'),
  windowSeconds: z.union([z.literal(30), z.literal(60)]),
  symbols: z.array(z.string()).optional(),
});

const MarketSubscriptionSchema = z.union([
  z.object({
    topic: z.literal('market'),
    assetIds: z.array(z.string()),
    tokenIds: z.never().optional(),
    customFeatureEnabled: z.boolean().optional(),
  }),
  z.object({
    topic: z.literal('market'),
    assetIds: z.never().optional(),
    tokenIds: z.array(z.string()),
    customFeatureEnabled: z.boolean().optional(),
  }),
]);

/**
 * Starts one or more realtime subscriptions on this client.
 *
 * The `prices.crypto`, `prices.crypto.twap`, `prices.equity`, and
 * `prices.equity.twap` topics
 * require a secure client and explicit filters, and include history snapshots
 * and live updates. Legacy source-named topics retain their existing behavior.
 * These four topics include `source`, identifying the source of the update
 * or entire history batch, including empty batches. Unknown source names remain
 * strings. Crypto sources are constant; equity sources may change across
 * reconnects. Cached history starts fresh whenever the source changes.
 * These four topics accept an optional `provider` pin. Omit it to follow the
 * default. A pin may fall back or be ignored when selection is disabled;
 * `source` always identifies the actual producer. Different provider choices,
 * including omission, use separate connections, even if they serve the same source.
 * An optional `onSubscribed` callback reports the provider the server confirms,
 * on acceptance and after every reconnect.
 * Event `seq` values are scoped to one channel on one WebSocket connection and
 * reset after reconnecting. Subscriptions with more than 64 filters use
 * multiple connections, so their sequence values may interleave.
 *
 * @remarks
 * This is a low-level function. Most SDK consumers should prefer the client instance API.
 *
 * @throws {@link SubscribeError}
 * Thrown when subscription input is invalid or a realtime subscription fails.
 *
 * @example
 * ```ts
 * const handle = await client.subscribe([
 *   { topic: 'market', assetIds: ['123'] },
 * ]);
 *
 * for await (const event of handle) {
 *   // event: StandardMarketEvent
 * }
 * ```
 */
export async function subscribe<
  const TSubscriptions extends readonly PublicSubscriptionSpec[],
>(
  client: BasePublicClient,
  subscriptions: TSubscriptions,
): Promise<SubscriptionHandle<EventForSubscriptionSpecs<TSubscriptions>>>;
export async function subscribe<
  const TSubscriptions extends readonly SecureSubscriptionSpec[],
>(
  client: BaseSecureClient,
  subscriptions: TSubscriptions,
): Promise<SubscriptionHandle<EventForSubscriptionSpecs<TSubscriptions>>>;
export async function subscribe(
  client: BaseClient,
  subscriptions: readonly SecureSubscriptionSpec[],
): Promise<SubscriptionHandle<unknown>> {
  const validatedSubscriptions = subscriptions.map((subscription) => {
    parseUserInput(subscription, SubscriptionTopicSchema);
    switch (subscription.topic) {
      case 'prices.crypto':
      case 'prices.crypto.twap':
      case 'prices.equity':
      case 'prices.equity.twap':
        if (!client.isSecureClient())
          throw new UserInputError(
            'This subscription requires a secure client.',
          );
        return parsePriceSubscription(subscription);
      case 'prices.crypto.chainlink.twap':
        parseUserInput(subscription, LegacyTwapSubscriptionSchema);
        break;
      case 'market':
        parseUserInput(subscription, MarketSubscriptionSchema);
        break;
    }
    return subscription;
  });

  const results = await Promise.allSettled(
    validatedSubscriptions.map(async (spec) => subscribeOne(client, spec)),
  );
  const handles = results.flatMap((result) =>
    result.status === 'fulfilled' ? [result.value] : [],
  );
  const failure = results.find((result) => result.status === 'rejected');
  if (failure?.status === 'rejected') {
    await Promise.allSettled(handles.map((handle) => handle.close()));
    throw failure.reason;
  }
  return mergedSubscription(handles);
}

function subscribeOne(
  client: BaseClient,
  spec: SecureSubscriptionSpec,
): Promise<SubscriptionHandle<unknown>> {
  switch (spec.topic) {
    case 'market':
      return client.webSockets.clobMarket.subscribe(spec);
    case 'sports':
      return client.webSockets.sports.subscribe(spec);
    case 'prices.crypto':
    case 'prices.crypto.twap':
    case 'prices.equity':
    case 'prices.equity.twap':
      if (!client.isSecureClient())
        throw new UserInputError('This subscription requires a secure client.');
      return client.webSockets.realtime.subscribe(spec);
    case 'comments':
    case 'prices.crypto.binance':
    case 'prices.crypto.chainlink':
    case 'prices.crypto.chainlink.twap':
    case 'prices.equity.pyth':
      return client.webSockets.rtds.subscribe(spec);
    case 'perps.trades':
    case 'perps.bbo':
    case 'perps.book':
    case 'perps.candles':
    case 'perps.tickers':
    case 'perps.statistics':
      return client.webSockets.perpsSubscriptions.subscribe(spec);
    case 'user':
      invariant(
        client.isSecureClient(),
        "A 'user' subscription requires a secure client instance.",
      );
      return client.webSockets.clobUser.subscribe(spec);
  }
}

function mergedSubscription<TEvent>(
  children: readonly SubscriptionHandle<TEvent>[],
): SubscriptionHandle<TEvent> {
  // Cache the in-flight or settled close so subsequent `close()` calls are
  // idempotent: concurrent callers share the same underlying teardown, and
  // callers after settlement observe the original result (including any
  // rejection) instead of re-invoking child teardowns.
  let closing: Promise<void> | undefined;

  async function close(): Promise<void> {
    if (closing === undefined) {
      closing = Promise.all(children.map((child) => child.close())).then(
        () => undefined,
      );
    }
    await closing;
  }

  const iterable = merge(...children);

  return {
    close,
    [Symbol.asyncIterator]() {
      return iterable[Symbol.asyncIterator]();
    },
  };
}
