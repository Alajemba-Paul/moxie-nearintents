import {
  OrderSide,
  toDecimalString,
  toEpochMilliseconds,
} from '@polymarket/bindings';
import {
  PerpsCancelOrderResultSchema,
  PerpsInstrumentIdSchema,
  PerpsKnownCancelOrderErrorCode,
  type PerpsPortfolio,
  PerpsTimeInForce,
} from '@polymarket/bindings/perps';
import { TypedData } from 'ox';
import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  OperationAbortedError,
  PerpsCancelRetryError,
  RequestRejectedError,
  TransportError,
  UnexpectedResponseError,
  UserInputError,
} from '../../../errors';
import { createPerpsOpTypedDataPayload } from '../signing';
import type { PerpsBuilderTermsInput } from './builder-terms';
import {
  cancelPerpsOrder,
  cancelPerpsOrders,
  type PerpsCommandExecutor,
  type PerpsCommandRequest,
  placePerpsPositionTpSl,
  postPerpsOrders,
  toPerpsCommandBodyOp,
  updatePerpsLeverage,
  updatePerpsLeverages,
  updatePerpsMargin,
} from './trading';

const CREATE_ORDER_DATA_HASH =
  '0x817207b7b8b31044a8f27e43c16e24d9fd5e11d3f106feb962f104f3ef28d52a';
const UPDATE_MARGIN_DATA_HASH =
  '0xf61d7d83b4367ce136bf66cfee6a5d41303a8b2d8724f5458f9812c46f5e55b3';
const UPDATE_LEVERAGES_DATA_HASH =
  '0xdcdd40c029abb105bb4911882321a203c294e9c4da73a32c5957afdbfb34cfdc';

afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
});

describe('Perps trading actions', () => {
  describe('GTD orders', () => {
    const expiry = 1_893_456_000_123;
    const order = {
      instrumentId: 1,
      side: OrderSide.BUY,
      price: '100.50',
      quantity: '10',
      timeInForce: PerpsTimeInForce.GTD,
      gtdExpiry: expiry,
      postOnly: true,
    } as const;
    it('preserves expiry before builder attribution in signed and keyed forms', async () => {
      const builder = {
        builderAddress: '0x1111111111111111111111111111111111111111',
        feeRate: '0.0005',
      };
      const executor: PerpsCommandExecutor = {
        builderAttribution: builder,
        async executeCommand(request, schema) {
          expect(request.expiresAt).toBe(1_893_455_000_000);
          expect(request.op).toEqual([
            'createOrders',
            [
              [
                1,
                true,
                '100.50',
                '10',
                'gtd',
                true,
                undefined,
                undefined,
                undefined,
                expiry,
                [builder.builderAddress, builder.feeRate],
              ],
            ],
          ]);
          expect(toPerpsCommandBodyOp(request.op)).toEqual({
            type: 'createOrders',
            args: [
              {
                iid: 1,
                buy: true,
                p: '100.50',
                qty: '10',
                tif: 'gtd',
                po: true,
                gtd_expiry: expiry,
                builder: {
                  address: builder.builderAddress,
                  fee_rate: builder.feeRate,
                },
              },
            ],
          });
          const payload = { chainId: 31337, salt: 1, timestamp: 1739491200000 };
          expect(
            createPerpsOpTypedDataPayload({ ...payload, op: request.op }),
          ).toEqual(
            createPerpsOpTypedDataPayload({
              ...payload,
              op: [
                'createOrders',
                [
                  [
                    1,
                    true,
                    '100.50',
                    '10',
                    'gtd',
                    true,
                    expiry,
                    [builder.builderAddress, builder.feeRate],
                  ],
                ],
              ],
            }),
          );
          return schema.parse([{ oid: 1, status: 'ok' }]);
        },
      };
      await postPerpsOrders(executor, {
        orders: [order],
        expiresAt: 1_893_455_000_000,
      });
    });
    it.each([
      { gtdExpiry: undefined },
      { gtdExpiry: 1 },
      { gtdExpiry: true },
      { gtdExpiry: 1.5 },
      { gtdExpiry: 18_446_744_073_710 },
      { price: undefined },
      { timeInForce: PerpsTimeInForce.GTC },
      { timeInForce: PerpsTimeInForce.IOC, postOnly: undefined },
      { timeInForce: PerpsTimeInForce.FOK, postOnly: undefined },
    ])('rejects a malformed later batch order before execution: %j', async (overrides) => {
      const executeCommand = vi.fn();
      const executor: PerpsCommandExecutor = { executeCommand };
      await expect(
        postPerpsOrders(executor, {
          orders: [order, { ...order, ...overrides } as never],
        }),
      ).rejects.toBeInstanceOf(UserInputError);
      expect(executeCommand).not.toHaveBeenCalled();
    });
    it('rejects expiry equal to the current time', async () => {
      vi.useFakeTimers({ now: expiry });
      const executeCommand = vi.fn();
      await expect(
        postPerpsOrders({ executeCommand }, { orders: [order] }),
      ).rejects.toBeInstanceOf(UserInputError);
      expect(executeCommand).not.toHaveBeenCalled();
    });
  });
  describe('builder attribution', () => {
    const builder = {
      builderAddress: '0x1111111111111111111111111111111111111111',
      feeRate: '0.0005000000000000000000000000',
    };
    const order = {
      instrumentId: 1,
      quantity: '10',
      side: OrderSide.BUY,
      timeInForce: PerpsTimeInForce.IOC,
    } as const;

    it('captures session terms once for the entire signed batch without rounding', async () => {
      let attributionReads = 0;
      const executor: PerpsCommandExecutor = {
        get builderAttribution() {
          attributionReads += 1;
          return attributionReads === 1 ? builder : undefined;
        },
        async executeCommand(request, schema) {
          expect(
            createPerpsOpTypedDataPayload({
              chainId: 31337,
              op: request.op,
              salt: 1,
              timestamp: 1739491200000,
            }).message.data,
          ).toEqual(
            createPerpsOpTypedDataPayload({
              chainId: 31337,
              op: [
                'createOrders',
                Array.from({ length: 2 }, () => [
                  1,
                  true,
                  '10',
                  'ioc',
                  false,
                  [builder.builderAddress, builder.feeRate],
                ]),
              ],
              salt: 1,
              timestamp: 1739491200000,
            }).message.data,
          );
          return schema.parse([{ oid: 123, status: 'ok' }]);
        },
      };
      await postPerpsOrders(executor, {
        orders: [order, order],
      });
    });
  });
  it.each([
    {
      size: '1',
      takeProfitQuantity: undefined,
      stopLossQuantity: undefined,
      quantities: ['0', '0'],
    },
    {
      size: '-1',
      takeProfitQuantity: '0.1234567890123456789012345678',
      stopLossQuantity: undefined,
      quantities: ['0.1234567890123456789012345678', '0'],
    },
    {
      size: '1',
      takeProfitQuantity: '0.25',
      stopLossQuantity: '0.75',
      quantities: ['0.25', '0.75'],
    },
    {
      size: '1',
      takeProfitQuantity: '0.0000000000000000000000000001',
      stopLossQuantity: '79228162514264337593543950335',
      quantities: [
        '0.0000000000000000000000000001',
        '79228162514264337593543950335',
      ],
    },
    {
      size: '-1',
      takeProfitQuantity: 0.25,
      stopLossQuantity: '0.7500',
      quantities: ['0.25', '0.7500'],
    },
  ])('preserves position exit quantities, side, and captured builder terms for $size', async ({
    size,
    takeProfitQuantity,
    stopLossQuantity,
    quantities,
  }) => {
    const initialTerms = {
      builderAddress: '0x1111111111111111111111111111111111111111',
      feeRate: '0.0003',
    };
    let activeTerms: PerpsBuilderTermsInput | undefined = initialTerms;
    const zero = toDecimalString('0');
    const executor: PerpsCommandExecutor & {
      fetchPortfolio(): Promise<PerpsPortfolio>;
    } = {
      get builderAttribution() {
        return activeTerms;
      },
      async fetchPortfolio() {
        activeTerms = undefined;
        return {
          positions: [
            {
              instrumentId: PerpsInstrumentIdSchema.parse(1),
              symbol: 'BTC',
              size: toDecimalString(size),
              entryPrice: zero,
              leverage: 1,
              cross: true,
              initialMargin: zero,
              maintenanceMargin: zero,
              positionValue: zero,
              liquidationPrice: zero,
              unrealizedPnl: zero,
              returnOnEquity: zero,
              cumulativeFunding: zero,
              adlIndex: 0,
            },
          ],
          margin: {
            totalAccountValue: zero,
            availableOrderMargin: zero,
            totalInitialMargin: zero,
            totalMaintenanceMargin: zero,
            totalPositionValue: zero,
          },
          withdrawable: zero,
          inLiquidation: false,
          feeTier: 0,
          timestamp: toEpochMilliseconds(1),
        };
      },
      async executeCommand(request, schema) {
        expect(toPerpsCommandBodyOp(request.op)).toMatchObject({
          grp: 'position',
          args: [
            {
              buy: size.startsWith('-'),
              qty: quantities[0],
              ro: true,
              tr: { market: true, tpsl: 'tp', trp: '110' },
              builder: {
                address: initialTerms.builderAddress,
                fee_rate: initialTerms.feeRate,
              },
            },
            {
              buy: size.startsWith('-'),
              qty: quantities[1],
              ro: true,
              tr: { market: true, tpsl: 'sl', trp: '90' },
              builder: {
                address: initialTerms.builderAddress,
                fee_rate: initialTerms.feeRate,
              },
            },
          ],
        });
        return schema.parse([
          { oid: 123, status: 'ok' },
          { oid: 124, status: 'ok' },
        ]);
      },
    };
    await placePerpsPositionTpSl(executor, {
      instrumentId: 1,
      takeProfit: { triggerPrice: '110', quantity: takeProfitQuantity },
      stopLoss: { triggerPrice: '90', quantity: stopLossQuantity },
    });
  });
  it.each([
    {
      size: '1',
      takeProfitQuantity: undefined,
      stopLossQuantity: undefined,
      quantities: ['0', '0'],
    },
    {
      size: '-1',
      takeProfitQuantity: '0.1234567890123456789012345678',
      stopLossQuantity: undefined,
      quantities: ['0.1234567890123456789012345678', '0'],
    },
    {
      size: '1',
      takeProfitQuantity: '0.25',
      stopLossQuantity: '0.75',
      quantities: ['0.25', '0.75'],
    },
    {
      size: '1',
      takeProfitQuantity: '0.0000000000000000000000000001',
      stopLossQuantity: '79228162514264337593543950335',
      quantities: [
        '0.0000000000000000000000000001',
        '79228162514264337593543950335',
      ],
    },
    {
      size: '-1',
      takeProfitQuantity: 0.25,
      stopLossQuantity: '0.7500',
      quantities: ['0.25', '0.7500'],
    },
  ])('preserves trailing position exit quantities, side, and captured builder terms for $size', async ({
    size,
    takeProfitQuantity,
    stopLossQuantity,
    quantities,
  }) => {
    const trailingBps = stopLossQuantity === undefined ? 10 : 2000;
    const activationPrice = stopLossQuantity === undefined ? undefined : '105';
    const initialTerms = {
      builderAddress: '0x1111111111111111111111111111111111111111',
      feeRate: '0.0003',
    };
    let activeTerms: PerpsBuilderTermsInput | undefined = initialTerms;
    const zero = toDecimalString('0');
    const executor: PerpsCommandExecutor & {
      fetchPortfolio(): Promise<PerpsPortfolio>;
    } = {
      get builderAttribution() {
        return activeTerms;
      },
      async fetchPortfolio() {
        activeTerms = undefined;
        return {
          positions: [
            {
              instrumentId: PerpsInstrumentIdSchema.parse(1),
              symbol: 'BTC',
              size: toDecimalString(size),
              entryPrice: zero,
              leverage: 1,
              cross: true,
              initialMargin: zero,
              maintenanceMargin: zero,
              positionValue: zero,
              liquidationPrice: zero,
              unrealizedPnl: zero,
              returnOnEquity: zero,
              cumulativeFunding: zero,
              adlIndex: 0,
            },
          ],
          margin: {
            totalAccountValue: zero,
            availableOrderMargin: zero,
            totalInitialMargin: zero,
            totalMaintenanceMargin: zero,
            totalPositionValue: zero,
          },
          withdrawable: zero,
          inLiquidation: false,
          feeTier: 0,
          timestamp: toEpochMilliseconds(1),
        };
      },
      async executeCommand(request, schema) {
        expect(toPerpsCommandBodyOp(request.op)).toMatchObject({
          grp: 'position',
          args: [
            {
              buy: size.startsWith('-'),
              qty: quantities[0],
              ro: true,
              tr: { market: true, tpsl: 'tp', trp: '110' },
              builder: {
                address: initialTerms.builderAddress,
                fee_rate: initialTerms.feeRate,
              },
            },
            {
              buy: size.startsWith('-'),
              qty: quantities[1],
              ro: true,
              tr: {
                market: true,
                tpsl: 'sl',
                trail_bps: trailingBps,
                ...(activationPrice === undefined
                  ? {}
                  : { act: activationPrice }),
              },
              builder: {
                address: initialTerms.builderAddress,
                fee_rate: initialTerms.feeRate,
              },
            },
          ],
        });
        return schema.parse([
          { oid: 123, status: 'ok' },
          { oid: 124, status: 'ok' },
        ]);
      },
    };
    await placePerpsPositionTpSl(executor, {
      instrumentId: 1,
      takeProfit: { triggerPrice: '110', quantity: takeProfitQuantity },
      stopLoss: {
        trailingBps,
        activationPrice,
        quantity: stopLossQuantity,
      },
    });
  });
  it.each([
    '0',
    '-0',
    '0.000',
    '-1',
    'NaN',
    'Infinity',
    'bad',
    '',
    '0x1',
    '1e-8',
    '0.00000000000000000000000000001',
    '79228162514264337593543950336',
    '7.9228162514264337593543950336',
    0,
    -1,
    1e-8,
    Number.NaN,
    Number.POSITIVE_INFINITY,
  ])('rejects the whole position pair before reading or executing when the second quantity is %s', async (quantity) => {
    const fetchPortfolio = vi.fn<() => Promise<PerpsPortfolio>>();
    const executeCommand = vi.fn(async () => {
      throw new Error('Unexpected command');
    });
    await expect(
      placePerpsPositionTpSl(
        { fetchPortfolio, executeCommand },
        {
          instrumentId: 1,
          takeProfit: { triggerPrice: '110', quantity: '0.25' },
          stopLoss: { triggerPrice: '90', quantity },
        },
      ),
    ).rejects.toBeInstanceOf(UserInputError);
    expect(fetchPortfolio).not.toHaveBeenCalled();
    expect(executeCommand).not.toHaveBeenCalled();
  });
  it.each([
    { trailingBps: 9 },
    { trailingBps: 2001 },
    { trailingBps: 10.5 },
    { trailingBps: true },
    { trailingBps: 200, triggerPrice: '90' },
    { trailingBps: 200, limitPrice: '90' },
    { activationPrice: '100' },
    { trailingBps: 200, gtdExpiry: 1893456000000 },
    { trailingBps: 200, activationPrice: '0' },
    { trailingBps: 200, activationPrice: '-1' },
    { trailingBps: 200, activationPrice: '1e-29' },
    { trailingBps: 200, quantity: '0' },
    { trailingBps: 200, quantity: '0.00000000000000000000000000001' },
    { trailingBps: 200, quantity: '79228162514264337593543950336' },
  ])('rejects invalid trailing intent before portfolio reads: %j', async (stopLoss) => {
    const fetchPortfolio = vi.fn<() => Promise<PerpsPortfolio>>();
    const executeCommand = vi.fn(async () => {
      throw new Error('Unexpected command');
    });
    await expect(
      placePerpsPositionTpSl(
        { fetchPortfolio, executeCommand },
        {
          instrumentId: 1,
          takeProfit: { triggerPrice: '110' },
          stopLoss: stopLoss as never,
        },
      ),
    ).rejects.toBeInstanceOf(UserInputError);
    expect(fetchPortfolio).not.toHaveBeenCalled();
    expect(executeCommand).not.toHaveBeenCalled();
  });

  it('rejects trailing fields on static take-profit intent before reads', async () => {
    const fetchPortfolio = vi.fn<() => Promise<PerpsPortfolio>>();
    const executeCommand = vi.fn(async () => {
      throw new Error('Unexpected command');
    });
    await expect(
      placePerpsPositionTpSl(
        { fetchPortfolio, executeCommand },
        {
          instrumentId: 1,
          takeProfit: { triggerPrice: '110', trailingBps: 200 } as never,
        },
      ),
    ).rejects.toBeInstanceOf(UserInputError);
    expect(fetchPortfolio).not.toHaveBeenCalled();
    expect(executeCommand).not.toHaveBeenCalled();
  });

  it('pins trailing trigger field order with omitted GTD and builder attribution', () => {
    const op = [
      'createOrders',
      [
        [
          1,
          false,
          undefined,
          '0.25',
          undefined,
          false,
          true,
          undefined,
          [true, undefined, 'sl', 200, '105'],
          undefined,
          ['0x1111111111111111111111111111111111111111', '0.0003'],
        ],
      ],
      'position',
    ] as const;
    expect(toPerpsCommandBodyOp(op)).toEqual({
      type: 'createOrders',
      grp: 'position',
      args: [
        {
          iid: 1,
          buy: false,
          po: false,
          qty: '0.25',
          ro: true,
          tr: { market: true, tpsl: 'sl', trail_bps: 200, act: '105' },
          builder: {
            address: '0x1111111111111111111111111111111111111111',
            fee_rate: '0.0003',
          },
        },
      ],
    });
    // Generated directly from the pinned CreateOrderTr declaration's compact grammar.
    expect(
      createPerpsOpTypedDataPayload({
        chainId: 137,
        op,
        salt: 1,
        timestamp: 1751500000000,
      }).message.data,
    ).toBe(
      '0x26fa3c30a20b82e2ea6ac87c42f2bc733af22cefa74038f08f74c0f7e151c885',
    );
  });

  describe('createPerpsOpTypedDataPayload', () => {
    it('matches backend approval bytes and binds the version and maximum rate', () => {
      function approvalHash(maxFeeRate: string, approvalVersion: number) {
        return createPerpsOpTypedDataPayload({
          chainId: 31_337,
          op: [
            'approveBuilder',
            [
              '0x0000000000000000000000000000000000001234',
              maxFeeRate,
              approvalVersion,
            ],
          ],
          salt: 1,
          timestamp: 1_739_491_200_000,
        }).message.data;
      }
      // This serializer fixture comes from the backend; its above-cap rate
      // deliberately bypasses user-input validation to pin the signed bytes.
      const hash = approvalHash('0.002', 1);
      expect(hash).toBe(
        '0x3f1cc1f398302e8b00fa75c4f5d2ca0e8464014785a365873fd41582b7280a9b',
      );
      expect(approvalHash('0.002', 2)).not.toBe(hash);
      expect(approvalHash('0', 1)).not.toBe(hash);
    });
    it('matches the backend nested builder signing fixture', () => {
      // This backend serializer fixture intentionally exceeds the admission
      // cap; it tests signing independently of SDK user-input validation.
      const payload = createPerpsOpTypedDataPayload({
        chainId: 31_337,
        op: [
          'createOrders',
          [
            [
              1,
              true,
              '100.50',
              '10',
              'gtc',
              false,
              undefined,
              undefined,
              undefined,
              undefined,
              ['0x0000000000000000000000000000000000001234', '0.002'],
            ],
          ],
        ],
        salt: 1,
        timestamp: 1_739_491_200_000,
      });
      expect(payload.message.data).toBe(
        '0xb712d9d3d4ba4c722daf48c55e3b0c5450abb64477c7c6765fa5c09e1d4805c2',
      );
    });
    it('signs entry orders with backend-compatible createOrders bytes', async () => {
      const client: PerpsCommandExecutor = {
        async executeCommand(request, responseSchema) {
          const payload = createPerpsOpTypedDataPayload({
            chainId: 31_337,
            op: request.op,
            salt: 1,
            timestamp: 1_739_491_200_000,
          });

          expect(payload.message).toMatchObject({
            data: CREATE_ORDER_DATA_HASH,
            salt: 1n,
            ts: 1_739_491_200_000n,
          });
          const { EIP712Domain, ...types } = payload.types;
          expect(EIP712Domain).toEqual([
            { name: 'name', type: 'string' },
            { name: 'version', type: 'string' },
            { name: 'chainId', type: 'uint256' },
          ]);
          expect(TypedData.getSignPayload(payload)).toBe(
            TypedData.getSignPayload({
              ...payload,
              types,
            }),
          );
          expect(toPerpsCommandBodyOp(request.op)).toEqual({
            args: [
              {
                buy: true,
                iid: 1,
                p: '100.50',
                po: false,
                qty: '10',
                tif: 'gtc',
              },
            ],
            type: 'createOrders',
          });

          return responseSchema.parse([{ oid: 123, status: 'ok' }]);
        },
      };

      await expect(
        postPerpsOrders(client, {
          orders: [
            {
              instrumentId: 1,
              postOnly: false,
              price: '100.50',
              quantity: '10',
              side: OrderSide.BUY,
              timeInForce: PerpsTimeInForce.GTC,
            },
          ],
        }),
      ).resolves.toMatchObject([{ orderId: 123, status: 'ok' }]);
    });

    it('serializes reduce-only entry orders', async () => {
      const client: PerpsCommandExecutor = {
        async executeCommand(request, responseSchema) {
          expect(toPerpsCommandBodyOp(request.op)).toEqual({
            args: [
              {
                buy: false,
                iid: 1,
                p: '100.50',
                po: false,
                qty: '10',
                ro: true,
                tif: 'ioc',
              },
            ],
            type: 'createOrders',
          });

          return responseSchema.parse([{ oid: 123, status: 'ok' }]);
        },
      };

      await expect(
        postPerpsOrders(client, {
          orders: [
            {
              instrumentId: 1,
              price: '100.50',
              quantity: '10',
              reduceOnly: true,
              side: OrderSide.SELL,
              timeInForce: PerpsTimeInForce.IOC,
            },
          ],
        }),
      ).resolves.toMatchObject([{ orderId: 123, status: 'ok' }]);
    });

    it('signs isolated margin adjustments with backend-compatible bytes', async () => {
      const client: PerpsCommandExecutor = {
        async executeCommand(request, responseSchema) {
          const payload = createPerpsOpTypedDataPayload({
            chainId: 31_337,
            op: request.op,
            salt: 1,
            timestamp: 1_739_491_200_000,
          });

          expect(payload.message).toMatchObject({
            data: UPDATE_MARGIN_DATA_HASH,
            salt: 1n,
            ts: 1_739_491_200_000n,
          });
          expect(toPerpsCommandBodyOp(request.op)).toEqual({
            args: {
              amt: '-1234567890.123456789012345678',
              iid: 7,
            },
            type: 'updateMargin',
          });

          return responseSchema.parse({ status: 'ok' });
        },
      };

      await expect(
        updatePerpsMargin(client, {
          amount: '-1234567890.123456789012345678',
          instrumentId: 7,
        }),
      ).resolves.toBeUndefined();
    });

    it('signs ordered leverage batches with backend-compatible bytes', async () => {
      const client: PerpsCommandExecutor = {
        async executeCommand(request, responseSchema) {
          const payload = createPerpsOpTypedDataPayload({
            chainId: 31_337,
            op: request.op,
            salt: 1,
            timestamp: 1_739_491_200_000,
          });

          expect(payload.message).toMatchObject({
            data: UPDATE_LEVERAGES_DATA_HASH,
            salt: 1n,
            ts: 1_739_491_200_000n,
          });
          expect(request.op).toEqual([
            'updateLeverages',
            [
              [1, 5, false],
              [2, 10, true],
            ],
          ]);
          expect(toPerpsCommandBodyOp(request.op)).toEqual({
            args: [
              { cross: false, iid: 1, lev: 5 },
              { cross: true, iid: 2, lev: 10 },
            ],
            type: 'updateLeverages',
          });

          return responseSchema.parse([
            {
              status: 'ok',
              instrument_id: 1,
              leverage: 5,
              cross: false,
            },
            {
              status: 'err',
              instrument_id: 2,
              error: 'internal_error',
            },
          ]);
        },
      };

      await expect(
        updatePerpsLeverages(client, {
          updates: [
            { crossMargin: false, instrumentId: 1, leverage: 5 },
            { crossMargin: true, instrumentId: 2, leverage: 10 },
          ],
        }),
      ).resolves.toEqual([
        {
          status: 'ok',
          instrumentId: 1,
          leverage: 5,
          crossMargin: false,
        },
        { status: 'err', instrumentId: 2, error: 'internal_error' },
      ]);
    });
  });

  describe('updatePerpsLeverages', () => {
    it.each([
      {
        field: 'instrument id',
        update: {
          crossMargin: true,
          instrumentId: 4_294_967_296,
          leverage: 1,
        },
      },
      {
        field: 'leverage',
        update: {
          crossMargin: true,
          instrumentId: 1,
          leverage: 4_294_967_296,
        },
      },
    ])('validates batch $field bounds while preserving single-update behavior', async ({
      field,
      update,
    }) => {
      const rejection = new RequestRejectedError(`${field} is out of range`, {
        status: 400,
      });
      let executions = 0;
      const client: PerpsCommandExecutor = {
        async executeCommand() {
          executions++;
          throw rejection;
        },
      };

      await expect(updatePerpsLeverage(client, update)).rejects.toBe(rejection);
      await expect(
        updatePerpsLeverages(client, { updates: [update] }),
      ).rejects.toBeInstanceOf(UserInputError);
      expect(executions).toBe(1);
    });

    it.each([1, 100])('accepts the %i-item boundary', async (size) => {
      let executions = 0;
      const client: PerpsCommandExecutor = {
        async executeCommand(request, responseSchema) {
          executions++;
          expect(request.op[1]).toHaveLength(size);
          return responseSchema.parse(
            Array.from({ length: size }, (_, instrumentId) => ({
              status: 'ok',
              instrument_id: instrumentId,
              leverage: 1,
              cross: true,
            })),
          );
        },
      };

      await expect(
        updatePerpsLeverages(client, {
          updates: Array.from({ length: size }, (_, instrumentId) => ({
            crossMargin: true,
            instrumentId,
            leverage: 1,
          })),
        }),
      ).resolves.toHaveLength(size);
      expect(executions).toBe(1);
    });

    it.each([
      ['an empty batch', []],
      [
        'more than 100 updates',
        Array.from({ length: 101 }, (_, instrumentId) => ({
          crossMargin: true,
          instrumentId,
          leverage: 1,
        })),
      ],
      [
        'duplicate instrument ids',
        [
          { crossMargin: true, instrumentId: 1, leverage: 1 },
          { crossMargin: false, instrumentId: 1, leverage: 2 },
        ],
      ],
      [
        'a negative instrument id',
        [
          {
            crossMargin: true,
            instrumentId: -1,
            leverage: 1,
          },
        ],
      ],
      [
        'zero leverage',
        [
          {
            crossMargin: true,
            instrumentId: 1,
            leverage: 0,
          },
        ],
      ],
    ])('rejects %s before executing the command', async (_, updates) => {
      let executions = 0;
      const client: PerpsCommandExecutor = {
        async executeCommand() {
          executions++;
          throw new Error('The executor should not be called.');
        },
      };

      await expect(
        updatePerpsLeverages(client, { updates }),
      ).rejects.toBeInstanceOf(UserInputError);
      expect(executions).toBe(0);
    });
  });

  describe('cancelPerpsOrders', () => {
    it('retries only in-flight orders and preserves result order', async () => {
      vi.spyOn(Math, 'random').mockReturnValue(0);
      const { client, requests } = cancelExecutor([
        [
          { error: 'order_in_flight', oid: 1, status: 'err' },
          { error: 'unknown_error_code_18', oid: 2, status: 'err' },
          { oid: 3, status: 'ok' },
        ],
        [{ oid: 1, status: 'ok' }],
      ]);

      await expect(
        cancelPerpsOrders(client, {
          orderIds: [1, 2, 3],
          retry: { maxAttempts: 2, maxElapsedMs: 1_000 },
        }),
      ).resolves.toEqual([
        { clientOrderId: undefined, orderId: 1, status: 'ok' },
        {
          clientOrderId: undefined,
          error: 'unknown_error_code_18',
          orderId: 2,
          status: 'err',
        },
        { clientOrderId: undefined, orderId: 3, status: 'ok' },
      ]);
      expect(requests.map((request) => request.op)).toEqual([
        ['cancelOrders', [1, 2, 3]],
        ['cancelOrders', [1]],
      ]);
    });

    it.each([
      {
        failure: 'request-level rejection',
        response: [{ error: 'invalid_request', status: 'err' }],
        cause: expect.objectContaining({
          name: RequestRejectedError.name,
          message: 'invalid_request',
          status: 200,
        }),
      },
      {
        failure: 'transport failure',
        response: { error: new TransportError('Connection lost.') },
        cause: expect.any(TransportError),
      },
      {
        failure: 'missing result',
        response: [{ oid: 22, status: 'ok' }],
        cause: expect.any(UnexpectedResponseError),
      },
      {
        failure: 'extra result',
        response: [
          { oid: 22, status: 'ok' },
          { oid: 44, status: 'ok' },
          { oid: 55, status: 'ok' },
        ],
        cause: expect.any(UnexpectedResponseError),
      },
    ])('preserves collected results after a later $failure', async ({
      response,
      cause,
    }) => {
      vi.spyOn(Math, 'random').mockReturnValue(0);
      const firstResults = [
        { oid: 11, status: 'ok' },
        { error: 'order_in_flight', oid: 22, status: 'err' },
        { error: 'unknown_error_code_18', oid: 33, status: 'err' },
        { error: 'order_in_flight', oid: 44, status: 'err' },
      ];
      const { client, requests } = cancelExecutor([firstResults, response]);

      const error = await cancelPerpsOrders(client, {
        orderIds: [11, 22, 33, 44],
      }).catch((error: unknown) => error);

      expect(error).toBeInstanceOf(PerpsCancelRetryError);
      expect(error).toMatchObject({
        cause,
        pendingIndexes: [1, 3],
        results: firstResults.map((result) =>
          PerpsCancelOrderResultSchema.parse(result),
        ),
      });
      if (!Array.isArray(response)) {
        if (!(error instanceof PerpsCancelRetryError)) throw error;
        expect(error.cause).toBe(response.error);
      }
      expect(requests.map((request) => request.op)).toEqual([
        ['cancelOrders', [11, 22, 33, 44]],
        ['cancelOrders', [22, 44]],
      ]);
    });

    it('keeps second-attempt updates when the third client-ID attempt fails', async () => {
      vi.spyOn(Math, 'random').mockReturnValue(0);
      const firstId = 'a'.repeat(32);
      const secondId = 'b'.repeat(32);
      const thirdId = 'c'.repeat(32);
      const fourthId = 'd'.repeat(32);
      const firstResults = [
        { coid: firstId, status: 'ok' },
        { error: 'order_in_flight', coid: secondId, status: 'err' },
        { error: 'order_in_flight', coid: thirdId, status: 'err' },
        { error: 'order_in_flight', coid: fourthId, status: 'err' },
      ];
      const secondResults = [
        { coid: secondId, status: 'ok' },
        { error: 'unknown_error_code_18', coid: thirdId, status: 'err' },
        { error: 'order_in_flight', coid: fourthId, status: 'err' },
      ];
      const cause = new TransportError('Connection lost.');
      const { client, requests } = cancelExecutor([
        firstResults,
        secondResults,
        { error: cause },
      ]);

      const error = await cancelPerpsOrders(client, {
        clientOrderIds: [firstId, secondId, thirdId, fourthId],
      }).catch((error: unknown) => error);

      expect(error).toBeInstanceOf(PerpsCancelRetryError);
      if (!(error instanceof PerpsCancelRetryError)) throw error;
      expect(error.cause).toBe(cause);
      expect(error.pendingIndexes).toEqual([3]);
      expect(error.results).toEqual(
        [firstResults[0], ...secondResults].map((result) =>
          PerpsCancelOrderResultSchema.parse(result),
        ),
      );
      expect(requests.map((request) => request.op)).toEqual([
        ['cancelOrdersCOID', [firstId, secondId, thirdId, fourthId]],
        ['cancelOrdersCOID', [secondId, thirdId, fourthId]],
        ['cancelOrdersCOID', [fourthId]],
      ]);
    });

    it.each([
      {
        request: { orderId: 7 },
        response: { oid: 7, status: 'err', error: 'order_in_flight' },
      },
      {
        request: { clientOrderId: 'a'.repeat(32) },
        response: {
          coid: 'a'.repeat(32),
          status: 'err',
          error: 'order_in_flight',
        },
      },
    ])('preserves retry failure details through the single-order wrapper for $request', async ({
      request,
      response,
    }) => {
      vi.spyOn(Math, 'random').mockReturnValue(0);
      const cause = { message: 'Non-Error executor failure.' };
      const { client, requests } = cancelExecutor([
        [response],
        { error: cause },
      ]);

      const error = await cancelPerpsOrder(client, request).catch(
        (error: unknown) => error,
      );

      expect(error).toBeInstanceOf(PerpsCancelRetryError);
      if (!(error instanceof PerpsCancelRetryError)) throw error;
      expect(error.cause).toBe(cause);
      expect(error.pendingIndexes).toEqual([0]);
      expect(error.results).toEqual([
        PerpsCancelOrderResultSchema.parse(response),
      ]);
      expect(requests).toHaveLength(2);
    });

    it.each([
      new TransportError('Connection lost.'),
      { message: 'Executor failure.' },
    ])('propagates a first-attempt throwable unchanged', async (cause) => {
      const { client, requests } = cancelExecutor([{ error: cause }]);

      await expect(cancelPerpsOrders(client, { orderIds: [1] })).rejects.toBe(
        cause,
      );
      expect(requests).toHaveLength(1);
    });

    it('snapshots the retry error result and pending-index arrays', () => {
      const results = [
        PerpsCancelOrderResultSchema.parse({
          error: 'order_in_flight',
          oid: 1,
          status: 'err',
        }),
      ];
      const pendingIndexes = [0];
      const error = new PerpsCancelRetryError('Retry failed.', {
        results,
        pendingIndexes,
      });

      results.length = 0;
      pendingIndexes[0] = 2;

      expect(error.results).toEqual([
        {
          clientOrderId: undefined,
          error: 'order_in_flight',
          orderId: 1,
          status: 'err',
        },
      ]);
      expect(error.pendingIndexes).toEqual([0]);
    });

    it.each([
      PerpsKnownCancelOrderErrorCode.OrderUnknown,
      PerpsKnownCancelOrderErrorCode.OrderNotInOrderbook,
      PerpsKnownCancelOrderErrorCode.OrderNotPendingEngine,
      PerpsKnownCancelOrderErrorCode.OrderNotFound,
    ])('does not retry the terminal %s result', async (error) => {
      const { client, requests } = cancelExecutor([
        [{ error, oid: 1, status: 'err' }],
      ]);

      const result = await cancelPerpsOrders(client, {
        orderIds: [1],
        retry: { maxAttempts: 4, maxElapsedMs: 2_000 },
      });

      expect(result[0]).toMatchObject({ error, status: 'err' });
      expect(requests).toHaveLength(1);
    });

    it('supports disabling automatic retries', async () => {
      const { client, requests } = cancelExecutor([
        [{ error: 'order_in_flight', oid: 1, status: 'err' }],
      ]);

      await expect(
        cancelPerpsOrders(client, { orderIds: [1], retry: false }),
      ).resolves.toMatchObject([
        {
          error: PerpsKnownCancelOrderErrorCode.OrderInFlight,
          status: 'err',
        },
      ]);
      expect(requests).toHaveLength(1);
    });

    it('returns the last in-flight rejection after max attempts', async () => {
      vi.spyOn(Math, 'random').mockReturnValue(0);
      const { client, requests } = cancelExecutor([
        [{ error: 'order_in_flight', oid: 1, status: 'err' }],
        [{ error: 'order_in_flight', oid: 1, status: 'err' }],
        [{ error: 'order_in_flight', oid: 1, status: 'err' }],
      ]);

      const result = await cancelPerpsOrders(client, {
        orderIds: [1],
        retry: { maxAttempts: 3, maxElapsedMs: 2_000 },
      });

      expect(result).toMatchObject([
        {
          error: PerpsKnownCancelOrderErrorCode.OrderInFlight,
          orderId: 1,
          status: 'err',
        },
      ]);
      expect(requests).toHaveLength(3);
    });

    it('uses bounded exponential backoff with full jitter', async () => {
      vi.useFakeTimers();
      vi.spyOn(Math, 'random').mockReturnValue(0.5);
      const rejection = {
        error: 'order_in_flight',
        oid: 1,
        status: 'err',
      };
      const { client, requests } = cancelExecutor([
        [rejection],
        [rejection],
        [rejection],
        [rejection],
      ]);

      const result = cancelPerpsOrders(client, {
        orderIds: [1],
        retry: { maxAttempts: 4, maxElapsedMs: 10_000 },
      });
      await vi.advanceTimersByTimeAsync(0);
      expect(requests).toHaveLength(1);

      await vi.advanceTimersByTimeAsync(49);
      expect(requests).toHaveLength(1);
      await vi.advanceTimersByTimeAsync(1);
      expect(requests).toHaveLength(2);

      await vi.advanceTimersByTimeAsync(99);
      expect(requests).toHaveLength(2);
      await vi.advanceTimersByTimeAsync(1);
      expect(requests).toHaveLength(3);

      await vi.advanceTimersByTimeAsync(200);
      await expect(result).resolves.toMatchObject([
        {
          error: PerpsKnownCancelOrderErrorCode.OrderInFlight,
          status: 'err',
        },
      ]);
      expect(requests).toHaveLength(4);
    });

    it('does not start a retry outside the elapsed-time budget', async () => {
      vi.useFakeTimers({ now: 1_000 });
      vi.spyOn(Math, 'random').mockReturnValue(0.5);
      const { client, requests } = cancelExecutor([
        [{ error: 'order_in_flight', oid: 1, status: 'err' }],
      ]);

      await expect(
        cancelPerpsOrders(client, {
          orderIds: [1],
          retry: { maxAttempts: 4, maxElapsedMs: 50 },
        }),
      ).resolves.toMatchObject([
        {
          error: PerpsKnownCancelOrderErrorCode.OrderInFlight,
          status: 'err',
        },
      ]);
      expect(requests).toHaveLength(1);
    });

    it('does not retry when expiresAt cuts the elapsed-time budget short', async () => {
      vi.useFakeTimers({ now: 1_000 });
      vi.spyOn(Math, 'random').mockReturnValue(0.5);
      const { client, requests } = cancelExecutor([
        [{ error: 'order_in_flight', oid: 1, status: 'err' }],
      ]);

      await expect(
        cancelPerpsOrders(client, {
          orderIds: [1],
          expiresAt: 1_040,
          retry: { maxAttempts: 4, maxElapsedMs: 2_000 },
        }),
      ).resolves.toMatchObject([
        { error: 'order_in_flight', orderId: 1, status: 'err' },
      ]);
      expect(requests).toHaveLength(1);
      expect(requests[0]?.expiresAt).toBe(1_040);
    });

    it('returns received results when aborted during the first attempt', async () => {
      vi.spyOn(Math, 'random').mockReturnValue(0.5);
      const controller = new AbortController();
      let completeAttempt: () => void = () => {
        throw new Error('Expected the first attempt to be pending.');
      };
      const firstAttempt = new Promise<void>((resolve) => {
        completeAttempt = resolve;
      });
      const requests: PerpsCommandRequest[] = [];
      const client: PerpsCommandExecutor = {
        async executeCommand(request, responseSchema) {
          requests.push(request);
          await firstAttempt;
          return responseSchema.parse([
            { oid: 1, status: 'ok' },
            { error: 'order_in_flight', oid: 2, status: 'err' },
          ]);
        },
      };

      const result = cancelPerpsOrders(client, {
        orderIds: [1, 2],
        signal: controller.signal,
      });
      expect(requests).toHaveLength(1);
      controller.abort(new Error('Stop retrying.'));
      completeAttempt();

      await expect(result).resolves.toMatchObject([
        { orderId: 1, status: 'ok' },
        { error: 'order_in_flight', orderId: 2, status: 'err' },
      ]);
      expect(requests).toHaveLength(1);
    });

    it('returns collected results when retry backoff is aborted', async () => {
      vi.useFakeTimers();
      vi.spyOn(Math, 'random').mockReturnValue(0.5);
      const controller = new AbortController();
      const { client, requests } = cancelExecutor([
        [
          { oid: 1, status: 'ok' },
          { error: 'order_in_flight', oid: 2, status: 'err' },
        ],
      ]);

      const result = cancelPerpsOrders(client, {
        orderIds: [1, 2],
        retry: { maxAttempts: 4, maxElapsedMs: 2_000 },
        signal: controller.signal,
      });
      await vi.advanceTimersByTimeAsync(0);
      controller.abort(new Error('stop retrying'));

      await expect(result).resolves.toEqual([
        { clientOrderId: undefined, orderId: 1, status: 'ok' },
        {
          clientOrderId: undefined,
          error: PerpsKnownCancelOrderErrorCode.OrderInFlight,
          orderId: 2,
          status: 'err',
        },
      ]);
      expect(requests).toHaveLength(1);
    });

    it('does not send a command when the signal is already aborted', async () => {
      const controller = new AbortController();
      const reason = new Error('do not cancel');
      controller.abort(reason);
      const { client, requests } = cancelExecutor([]);

      await expect(
        cancelPerpsOrders(client, {
          orderIds: [1],
          signal: controller.signal,
        }),
      ).rejects.toMatchObject({
        cause: reason,
        name: OperationAbortedError.name,
      });
      expect(requests).toHaveLength(0);
    });

    it.each([
      'invalid_request',
      'ip_rate_limited',
      'action_rate_limited',
      'internal_error',
      'message_rate_limited',
    ])('throws the request-level %s rejection for one order', async (error) => {
      const { client, requests } = cancelExecutor([[{ error, status: 'err' }]]);

      await expect(
        cancelPerpsOrders(client, { orderIds: [1], retry: false }),
      ).rejects.toMatchObject({
        message: error,
        name: RequestRejectedError.name,
      });
      expect(requests).toHaveLength(1);
    });

    it('keeps identified internal errors after narrowing the retry batch', async () => {
      vi.spyOn(Math, 'random').mockReturnValue(0);
      const { client, requests } = cancelExecutor([
        [
          { oid: 1, status: 'ok' },
          { error: 'order_in_flight', oid: 2, status: 'err' },
        ],
        [{ error: 'internal_error', oid: 2, status: 'err' }],
      ]);

      await expect(
        cancelPerpsOrders(client, {
          orderIds: [1, 2],
          retry: { maxAttempts: 2, maxElapsedMs: 1_000 },
        }),
      ).resolves.toEqual([
        { clientOrderId: undefined, orderId: 1, status: 'ok' },
        {
          clientOrderId: undefined,
          error: 'internal_error',
          orderId: 2,
          status: 'err',
        },
      ]);
      expect(requests.map((request) => request.op)).toEqual([
        ['cancelOrders', [1, 2]],
        ['cancelOrders', [2]],
      ]);
    });

    it('does not map a request-level rejection to the first batch item', async () => {
      const { client } = cancelExecutor([
        [{ error: 'invalid_request', status: 'err' }],
      ]);

      await expect(
        cancelPerpsOrders(client, { orderIds: [1, 2], retry: false }),
      ).rejects.toMatchObject({
        message: 'invalid_request',
        name: RequestRejectedError.name,
      });
    });

    it('rejects responses with missing batch results', async () => {
      const { client } = cancelExecutor([[{ oid: 1, status: 'ok' }]]);

      await expect(
        cancelPerpsOrders(client, { orderIds: [1, 2], retry: false }),
      ).rejects.toBeInstanceOf(UnexpectedResponseError);
    });
  });
});

function cancelExecutor(responses: Array<unknown[] | { error: unknown }>): {
  client: PerpsCommandExecutor;
  requests: PerpsCommandRequest[];
} {
  const requests: PerpsCommandRequest[] = [];
  let responseIndex = 0;
  return {
    client: {
      async executeCommand(request, responseSchema) {
        requests.push(request);
        const response = responses[responseIndex++];
        if (response === undefined) {
          throw new Error('Unexpected Perps cancel attempt.');
        }
        if (!Array.isArray(response)) throw response.error;
        return responseSchema.parse(response);
      },
    },
    requests,
  };
}
