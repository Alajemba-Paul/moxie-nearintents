import {
  OrderSide,
  OrderSideSchema,
  toDecimalString,
} from '@polymarket/bindings';
import {
  PerpsAutoCancelResponseSchema,
  PerpsCancelAllOrdersResponseSchema,
  type PerpsCancelOrderResult,
  PerpsCancelOrderResultSchema,
  type PerpsClientOrderId,
  PerpsClientOrderIdSchema,
  PerpsCommandAckSchema,
  type PerpsDecimalInput,
  PerpsDecimalInputSchema,
  type PerpsInstrumentId,
  PerpsInstrumentIdSchema,
  PerpsKnownCancelOrderErrorCode,
  type PerpsOrder,
  type PerpsOrderId,
  PerpsOrderIdSchema,
  type PerpsPortfolio,
  type PerpsPostOrderAck,
  PerpsPostOrderAckSchema,
  PerpsTimeInForce,
  PerpsTpSlKind,
  PerpsTpSlScope,
  type PerpsUpdateLeverageBatchResult,
  PerpsUpdateLeverageBatchResultSchema,
  type PerpsUpdateLeverageResult,
  PerpsUpdateLeverageResultSchema,
} from '@polymarket/bindings/perps';
import type {
  PerpsOrderUpdateEvent,
  PerpsSessionEvent,
} from '@polymarket/bindings/subscriptions';
import {
  expectPresent,
  invariant,
  setNonBlockingTimeout,
} from '@polymarket/types';
import { z } from 'zod';
import {
  AutoCancelDailyLimitError,
  makeErrorGuard,
  OperationAbortedError,
  PerpsCancelRetryError,
  RateLimitError,
  RequestRejectedError,
  SigningError,
  TransportError,
  UnexpectedResponseError,
  UserInputError,
} from '../../../errors';
import { parseUserInput } from '../../../input';
import type { ServiceClient } from '../../../ServiceClient';
import type { PerpsSignedOp } from '../signing';
import type { PerpsBuilderTermsInput } from './builder-terms';

const PerpsOrderBaseInputSchema = z.object({
  instrumentId: PerpsInstrumentIdSchema,
  side: OrderSideSchema,
  quantity: PerpsDecimalInputSchema,
  reduceOnly: z.boolean().default(false),
  clientOrderId: PerpsClientOrderIdSchema.optional(),
  gtdExpiry: z.never().optional(),
});

/**
 * Good-til-cancelled Perps order.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsPlaceGtcOrderRequest = {
  /** Perps instrument identifier to trade. */
  instrumentId: number;
  /** Trade direction. */
  side: OrderSide;
  /** Limit price. */
  price: PerpsDecimalInput;
  /** Order quantity. */
  quantity: PerpsDecimalInput;
  /** Good-til-cancelled execution. */
  timeInForce: PerpsTimeInForce.GTC;
  gtdExpiry?: never;
  /** Whether the order must rest instead of taking liquidity. */
  postOnly?: boolean;
  /** Whether the order may only reduce or close an existing position. */
  reduceOnly?: boolean;
  /** Optional caller-supplied idempotency identifier. */
  clientOrderId?: string;
};

const PerpsPlaceGtcOrderRequestSchema = PerpsOrderBaseInputSchema.extend({
  price: PerpsDecimalInputSchema,
  timeInForce: z.literal(PerpsTimeInForce.GTC),
  postOnly: z.boolean().default(false),
}) satisfies z.ZodType<PerpsPlaceGtcOrderRequest>;

/**
 * Good-till-date Perps order.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsPlaceGtdOrderRequest = {
  /** Perps instrument identifier to trade. */
  instrumentId: number;
  /** Trade direction. */
  side: OrderSide;
  /** Limit price. */
  price: PerpsDecimalInput;
  /** Order quantity. */
  quantity: PerpsDecimalInput;
  /** Good-till-date execution. */
  timeInForce: PerpsTimeInForce.GTD;
  /** Order expiration in Unix milliseconds, strictly future and at most 18446744073709. Separate from the command deadline. */
  gtdExpiry: number;
  /** Whether the order must rest instead of taking liquidity. */
  postOnly?: boolean;
  /** Whether the order may only reduce or close an existing position. */
  reduceOnly?: boolean;
  /** Optional caller-supplied idempotency identifier. */
  clientOrderId?: string;
};

const PerpsPlaceGtdOrderRequestSchema = PerpsOrderBaseInputSchema.extend({
  price: PerpsDecimalInputSchema,
  timeInForce: z.literal(PerpsTimeInForce.GTD),
  postOnly: z.boolean().default(false),
  gtdExpiry: z
    .number()
    .int()
    .positive()
    .max(18_446_744_073_709)
    .refine(
      (expiry) => expiry > Date.now(),
      'Order expiration must be strictly in the future.',
    ),
}) satisfies z.ZodType<PerpsPlaceGtdOrderRequest>;

/**
 * Immediate-or-cancel Perps order.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsPlaceIocOrderRequest = {
  /** Perps instrument identifier to trade. */
  instrumentId: number;
  /** Trade direction. */
  side: OrderSide;
  /** Optional limit price. Omit for market-style execution. */
  price?: PerpsDecimalInput;
  /** Order quantity. */
  quantity: PerpsDecimalInput;
  /** Immediate-or-cancel execution. */
  timeInForce: PerpsTimeInForce.IOC;
  gtdExpiry?: never;
  postOnly?: never;
  /** Whether the order may only reduce or close an existing position. */
  reduceOnly?: boolean;
  /** Optional caller-supplied idempotency identifier. */
  clientOrderId?: string;
};

const PerpsPlaceIocOrderRequestSchema = PerpsOrderBaseInputSchema.extend({
  price: PerpsDecimalInputSchema.optional(),
  timeInForce: z.literal(PerpsTimeInForce.IOC),
  postOnly: z.never().optional(),
}) satisfies z.ZodType<PerpsPlaceIocOrderRequest>;

/**
 * Fill-or-kill Perps order.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsPlaceFokOrderRequest = {
  /** Perps instrument identifier to trade. */
  instrumentId: number;
  /** Trade direction. */
  side: OrderSide;
  /** Optional limit price. Omit for market-style execution. */
  price?: PerpsDecimalInput;
  /** Order quantity. */
  quantity: PerpsDecimalInput;
  /** Fill-or-kill execution. */
  timeInForce: PerpsTimeInForce.FOK;
  gtdExpiry?: never;
  postOnly?: never;
  /** Whether the order may only reduce or close an existing position. */
  reduceOnly?: boolean;
  /** Optional caller-supplied idempotency identifier. */
  clientOrderId?: string;
};

const PerpsPlaceFokOrderRequestSchema = PerpsOrderBaseInputSchema.extend({
  price: PerpsDecimalInputSchema.optional(),
  timeInForce: z.literal(PerpsTimeInForce.FOK),
  postOnly: z.never().optional(),
}) satisfies z.ZodType<PerpsPlaceFokOrderRequest>;

/**
 * Request parameters for one Perps order.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsOrderRequest =
  | PerpsPlaceGtcOrderRequest
  | PerpsPlaceGtdOrderRequest
  | PerpsPlaceIocOrderRequest
  | PerpsPlaceFokOrderRequest;

const PerpsOrderRequestSchema = z.discriminatedUnion('timeInForce', [
  PerpsPlaceGtcOrderRequestSchema,
  PerpsPlaceGtdOrderRequestSchema,
  PerpsPlaceIocOrderRequestSchema,
  PerpsPlaceFokOrderRequestSchema,
]) satisfies z.ZodType<PerpsOrderRequest>;

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsTpSlTrigger = {
  triggerPrice: PerpsDecimalInput;
  limitPrice?: PerpsDecimalInput;
  gtdExpiry?: never;
  trailingBps?: never;
  activationPrice?: never;
};

const PerpsTpSlTriggerSchema = z.object({
  triggerPrice: PerpsDecimalInputSchema,
  trailingBps: z.never().optional(),
  activationPrice: z.never().optional(),
  gtdExpiry: z.never().optional(),
  limitPrice: PerpsDecimalInputSchema.optional(),
}) satisfies z.ZodType<PerpsTpSlTrigger>;

const PerpsPositionCloseQuantitySchema = PerpsDecimalInputSchema.refine(
  (value) =>
    /^\d+(?:\.\d{1,28})?$/.test(value) &&
    BigInt(value.replace('.', '')) > 0n &&
    BigInt(value.replace('.', '')) <= 79_228_162_514_264_337_593_543_950_335n,
  'Expected a positive, exactly representable decimal quantity (96-bit coefficient, at most 28 decimal places). Use a fixed-point string without exponent notation.',
).optional();

const PerpsPositionTpSlTriggerSchema = z.object({
  triggerPrice: PerpsDecimalInputSchema,
  trailingBps: z.never().optional(),
  activationPrice: z.never().optional(),
  gtdExpiry: z.never().optional(),
  quantity: PerpsPositionCloseQuantitySchema,
}) satisfies z.ZodType<PerpsPositionTpSlTrigger>;

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsPositionTpSlTrigger = {
  triggerPrice: PerpsDecimalInput;
  trailingBps?: never;
  activationPrice?: never;
  gtdExpiry?: never;
  /**
   * Positive fixed close quantity, clamped to the live position at trigger time.
   * Omit to close the full position. Use a fixed-point string for exact precision;
   * exponent notation, more than 28 decimal places, and coefficients exceeding
   * 96 bits are rejected before submission.
   */
  quantity?: PerpsDecimalInput;
};

/**
 * A market stop loss that follows favorable marks after activation.
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsTrailingStop = {
  /** Pullback in basis points, an integer from 10 through 2000. */
  trailingBps: number;
  /** Positive activation mark. Omit to start trailing when the leg arms. */
  activationPrice?: PerpsDecimalInput;
  triggerPrice?: never;
  limitPrice?: never;
  gtdExpiry?: never;
};

/**
 * A trailing market stop loss protecting an open position.
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsPositionTrailingStop = PerpsTrailingStop & {
  /** Positive, exactly representable close quantity. Omit to close the full position. */
  quantity?: PerpsDecimalInput;
};

const PerpsTrailingStopSchema = z.object({
  trailingBps: z.number().int().min(10).max(2000),
  activationPrice: PerpsDecimalInputSchema.refine(
    (value) =>
      /^\d+(?:\.\d{1,28})?$/.test(value) &&
      BigInt(value.replace('.', '')) > 0n &&
      BigInt(value.replace('.', '')) <= 79_228_162_514_264_337_593_543_950_335n,
    'Expected a positive, exactly representable fixed-point activation price.',
  ).optional(),
  triggerPrice: z.never().optional(),
  limitPrice: z.never().optional(),
  gtdExpiry: z.never().optional(),
}) satisfies z.ZodType<PerpsTrailingStop>;

const PerpsStopLossSchema = z.union([
  PerpsTpSlTriggerSchema,
  PerpsTrailingStopSchema,
]);
const PerpsPositionStopLossSchema = z.union([
  PerpsPositionTpSlTriggerSchema,
  PerpsTrailingStopSchema.extend({
    quantity: PerpsPositionCloseQuantitySchema,
  }),
]);

type PerpsTpSlPairRequest =
  | {
      takeProfit: PerpsTpSlTrigger;
      stopLoss?: PerpsTpSlTrigger | PerpsTrailingStop;
    }
  | {
      takeProfit?: PerpsTpSlTrigger;
      stopLoss: PerpsTpSlTrigger | PerpsTrailingStop;
    };

const PerpsTpSlPairSchema = z.union([
  z.object({
    takeProfit: PerpsTpSlTriggerSchema,
    stopLoss: PerpsStopLossSchema.optional(),
  }),
  z.object({
    takeProfit: PerpsTpSlTriggerSchema.optional(),
    stopLoss: PerpsStopLossSchema,
  }),
]) satisfies z.ZodType<PerpsTpSlPairRequest>;

/** @internal */
export type PerpsCommandRequest = {
  op: PerpsSignedOp;
  expiresAt?: number;
};

/** @internal */
export type PerpsCommandExecutor = {
  readonly builderAttribution?: PerpsBuilderTermsInput;
  /** @internal */
  executeCommand<T>(
    request: PerpsCommandRequest,
    responseSchema: z.ZodType<T>,
  ): Promise<T>;
};

/** @internal */
export type PerpsEventCommandExecutor = PerpsCommandExecutor & {
  /** @internal */
  executeCommandWithEvent<TResponse, TEvent extends PerpsSessionEvent>(
    request: PerpsCommandRequest,
    responseSchema: z.ZodType<TResponse>,
    predicate: (event: PerpsSessionEvent) => event is TEvent,
  ): Promise<readonly [TResponse, TEvent]>;
};

/** @internal */
export type PerpsDeleteCommandRequest<T> = PerpsCommandRequest & {
  path: string;
  responseSchema: z.ZodType<T>;
};

/** @internal */
export type PerpsDeleteCommandExecutor = {
  /** @internal */
  executeDeleteCommand<T>(request: PerpsDeleteCommandRequest<T>): Promise<T>;
};

/** @internal */
export type SignPerpsRestCommand = (
  op: PerpsSignedOp,
  expiresAt?: number,
) => Record<string, unknown>;

/**
 * Request parameters for posting one or more Perps orders.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PostPerpsOrdersRequest = {
  /** Orders to post as one command. */
  orders: PerpsOrderRequest[];
  /** Optional command expiration timestamp in milliseconds. */
  expiresAt?: number;
};

const PostPerpsOrdersRequestSchema = z.object({
  orders: z.array(PerpsOrderRequestSchema).min(1),
  expiresAt: z.number().int().positive().optional(),
}) satisfies z.ZodType<PostPerpsOrdersRequest>;

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function postPerpsOrders(
  client: PerpsCommandExecutor,
  request: PostPerpsOrdersRequest,
): Promise<PerpsPostOrderAck[]> {
  const params = parseUserInput(request, PostPerpsOrdersRequestSchema);
  const builderAttribution = client.builderAttribution;
  return await client.executeCommand(
    {
      op: [
        'createOrders',
        params.orders.map((order) =>
          toRawPerpsOrder(order, builderAttribution),
        ),
      ],
      expiresAt: params.expiresAt,
    },
    z.array(PerpsPostOrderAckSchema),
  );
}

const PlacePerpsOrderWithTpSlRequestSchema = z.intersection(
  PerpsOrderRequestSchema,
  z.intersection(
    PerpsTpSlPairSchema,
    z.object({
      clientOrderId: PerpsClientOrderIdSchema.default(randomClientOrderId),
      expiresAt: z.number().int().positive().optional(),
    }),
  ),
) satisfies z.ZodType<PlacePerpsOrderWithTpSlRequest>;

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PlacePerpsOrderRequest =
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Limit price. */
      price: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Good-till-date execution. */
      timeInForce: PerpsTimeInForce.GTD;
      /** Order expiration in Unix milliseconds, strictly future and at most 18446744073709. Separate from expiresAt. */
      gtdExpiry: number;
      /** Whether the order must rest instead of taking liquidity. */
      postOnly?: boolean;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      takeProfit?: never;
      stopLoss?: never;
    }
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Limit price. */
      price: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Good-til-cancelled execution. */
      timeInForce: PerpsTimeInForce.GTC;
      gtdExpiry?: never;
      /** Whether the order must rest instead of taking liquidity. */
      postOnly?: boolean;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      takeProfit?: never;
      stopLoss?: never;
    }
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Optional limit price. Omit for market-style execution. */
      price?: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Immediate-or-cancel execution. */
      timeInForce: PerpsTimeInForce.IOC;
      gtdExpiry?: never;
      postOnly?: never;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      takeProfit?: never;
      stopLoss?: never;
    }
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Optional limit price. Omit for market-style execution. */
      price?: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Fill-or-kill execution. */
      timeInForce: PerpsTimeInForce.FOK;
      gtdExpiry?: never;
      postOnly?: never;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      takeProfit?: never;
      stopLoss?: never;
    };

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PlacePerpsOrderWithTpSlRequest =
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Limit price. */
      price: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Good-till-date execution. */
      timeInForce: PerpsTimeInForce.GTD;
      /** Order expiration in Unix milliseconds, strictly future and at most 18446744073709. Separate from expiresAt. */
      gtdExpiry: number;
      /** Whether the order must rest instead of taking liquidity. */
      postOnly?: boolean;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      /** Optional take-profit trigger to place with the entry order. */
      takeProfit?: PerpsTpSlTrigger;
      /** Stop-loss trigger to place with the entry order. */
      stopLoss: PerpsTpSlTrigger | PerpsTrailingStop;
    }
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Limit price. */
      price: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Good-till-date execution. */
      timeInForce: PerpsTimeInForce.GTD;
      /** Order expiration in Unix milliseconds, strictly future and at most 18446744073709. Separate from expiresAt. */
      gtdExpiry: number;
      /** Whether the order must rest instead of taking liquidity. */
      postOnly?: boolean;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      /** Take-profit trigger to place with the entry order. */
      takeProfit: PerpsTpSlTrigger;
      /** Optional stop-loss trigger to place with the entry order. */
      stopLoss?: PerpsTpSlTrigger | PerpsTrailingStop;
    }
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Limit price. */
      price: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Good-til-cancelled execution. */
      timeInForce: PerpsTimeInForce.GTC;
      gtdExpiry?: never;
      /** Whether the order must rest instead of taking liquidity. */
      postOnly?: boolean;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      /** Take-profit trigger to place with the entry order. */
      takeProfit: PerpsTpSlTrigger;
      /** Optional stop-loss trigger to place with the entry order. */
      stopLoss?: PerpsTpSlTrigger | PerpsTrailingStop;
    }
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Limit price. */
      price: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Good-til-cancelled execution. */
      timeInForce: PerpsTimeInForce.GTC;
      gtdExpiry?: never;
      /** Whether the order must rest instead of taking liquidity. */
      postOnly?: boolean;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      /** Optional take-profit trigger to place with the entry order. */
      takeProfit?: PerpsTpSlTrigger;
      /** Stop-loss trigger to place with the entry order. */
      stopLoss: PerpsTpSlTrigger | PerpsTrailingStop;
    }
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Optional limit price. Omit for market-style execution. */
      price?: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Immediate-or-cancel execution. */
      timeInForce: PerpsTimeInForce.IOC;
      gtdExpiry?: never;
      postOnly?: never;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      /** Take-profit trigger to place with the entry order. */
      takeProfit: PerpsTpSlTrigger;
      /** Optional stop-loss trigger to place with the entry order. */
      stopLoss?: PerpsTpSlTrigger | PerpsTrailingStop;
    }
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Optional limit price. Omit for market-style execution. */
      price?: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Immediate-or-cancel execution. */
      timeInForce: PerpsTimeInForce.IOC;
      gtdExpiry?: never;
      postOnly?: never;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      /** Optional take-profit trigger to place with the entry order. */
      takeProfit?: PerpsTpSlTrigger;
      /** Stop-loss trigger to place with the entry order. */
      stopLoss: PerpsTpSlTrigger | PerpsTrailingStop;
    }
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Optional limit price. Omit for market-style execution. */
      price?: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Fill-or-kill execution. */
      timeInForce: PerpsTimeInForce.FOK;
      gtdExpiry?: never;
      postOnly?: never;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      /** Take-profit trigger to place with the entry order. */
      takeProfit: PerpsTpSlTrigger;
      /** Optional stop-loss trigger to place with the entry order. */
      stopLoss?: PerpsTpSlTrigger | PerpsTrailingStop;
    }
  | {
      /** Perps instrument identifier to trade. */
      instrumentId: number;
      /** Trade direction. */
      side: OrderSide;
      /** Optional limit price. Omit for market-style execution. */
      price?: PerpsDecimalInput;
      /** Order quantity. */
      quantity: PerpsDecimalInput;
      /** Fill-or-kill execution. */
      timeInForce: PerpsTimeInForce.FOK;
      gtdExpiry?: never;
      postOnly?: never;
      /** Whether the order may only reduce or close an existing position. */
      reduceOnly?: boolean;
      /** Optional caller-supplied idempotency identifier. Generated when omitted. */
      clientOrderId?: string;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
      /** Optional take-profit trigger to place with the entry order. */
      takeProfit?: PerpsTpSlTrigger;
      /** Stop-loss trigger to place with the entry order. */
      stopLoss: PerpsTpSlTrigger | PerpsTrailingStop;
    };

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PlacePerpsOrderRequestWithOptions =
  | PlacePerpsOrderRequest
  | PlacePerpsOrderWithTpSlRequest;

const PlacePerpsOrderRequestSchema = z.intersection(
  PerpsOrderRequestSchema,
  z.object({
    clientOrderId: PerpsClientOrderIdSchema.default(randomClientOrderId),
    expiresAt: z.number().int().positive().optional(),
    takeProfit: z.never().optional(),
    stopLoss: z.never().optional(),
  }),
) satisfies z.ZodType<PlacePerpsOrderRequest>;

const SuccessfulPerpsPostOrderAcksSchema = z
  .array(PerpsPostOrderAckSchema)
  .min(1)
  .refine(
    (acknowledgements) =>
      acknowledgements.every(
        (acknowledgement) => acknowledgement.status === 'ok',
      ),
    'Expected successful Perps order acknowledgements.',
  );

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsPlacedTpSlOrder = {
  orderId: PerpsOrderId;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsPlacedTpSlOrders = {
  takeProfit?: PerpsPlacedTpSlOrder;
  stopLoss?: PerpsPlacedTpSlOrder;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PlacePerpsOrderResult = {
  order: PerpsOrder;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PlacePerpsOrderWithTpSlResult = PlacePerpsOrderResult & {
  tpSl: PerpsPlacedTpSlOrders;
};

function hasPerpsTpSl(
  request: PlacePerpsOrderRequestWithOptions,
): request is PlacePerpsOrderWithTpSlRequest {
  return request.takeProfit !== undefined || request.stopLoss !== undefined;
}

/**
 * Places one Perps order and resolves with the first matching orders update.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function placePerpsOrder(
  client: PerpsEventCommandExecutor,
  request: PlacePerpsOrderWithTpSlRequest,
): Promise<PlacePerpsOrderWithTpSlResult>;
/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function placePerpsOrder(
  client: PerpsEventCommandExecutor,
  request: PlacePerpsOrderRequest,
): Promise<PlacePerpsOrderResult>;
/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function placePerpsOrder(
  client: PerpsEventCommandExecutor,
  request: PlacePerpsOrderRequestWithOptions,
): Promise<PlacePerpsOrderResult | PlacePerpsOrderWithTpSlResult>;
/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function placePerpsOrder(
  client: PerpsEventCommandExecutor,
  request: PlacePerpsOrderRequestWithOptions,
): Promise<PlacePerpsOrderResult | PlacePerpsOrderWithTpSlResult> {
  if (hasPerpsTpSl(request)) {
    return await placePerpsOrderWithTpSl(client, request);
  }

  const params = parseUserInput(request, PlacePerpsOrderRequestSchema);
  const builderAttribution = client.builderAttribution;
  const [, update] = await client.executeCommandWithEvent(
    {
      op: ['createOrders', [toRawPerpsOrder(params, builderAttribution)]],
      expiresAt: params.expiresAt,
    },
    SuccessfulPerpsPostOrderAcksSchema,
    isOrderUpdateFor(params.clientOrderId),
  );
  return { order: update.payload };
}

async function placePerpsOrderWithTpSl(
  client: PerpsEventCommandExecutor,
  request: PlacePerpsOrderWithTpSlRequest,
): Promise<PlacePerpsOrderWithTpSlResult> {
  const params = parseUserInput(request, PlacePerpsOrderWithTpSlRequestSchema);
  const builderAttribution = client.builderAttribution;
  const orders: RawPerpsOrderInput[] = [
    toRawPerpsOrder(params, builderAttribution),
  ];
  const exitBuy = params.side === OrderSide.SELL;

  if (params.takeProfit !== undefined) {
    orders.push(
      toRawPerpsTpSlOrder({
        buy: exitBuy,
        instrumentId: params.instrumentId,
        kind: PerpsTpSlKind.TakeProfit,
        quantity: toDecimalString(params.quantity),
        builderAttribution,
        trigger: params.takeProfit,
      }),
    );
  }
  if (params.stopLoss !== undefined) {
    orders.push(
      toRawPerpsTpSlOrder({
        buy: exitBuy,
        instrumentId: params.instrumentId,
        kind: PerpsTpSlKind.StopLoss,
        quantity: toDecimalString(params.quantity),
        builderAttribution,
        trigger: params.stopLoss,
      }),
    );
  }

  const [acknowledgements, update] = await client.executeCommandWithEvent(
    {
      op: ['createOrders', orders, PerpsTpSlScope.Order],
      expiresAt: params.expiresAt,
    },
    SuccessfulPerpsPostOrderAcksSchema,
    isOrderUpdateFor(params.clientOrderId),
  );

  let triggerIndex = 1;
  const tpSl: PerpsPlacedTpSlOrders = {};
  if (params.takeProfit !== undefined) {
    tpSl.takeProfit = placedOrderFrom(
      expectPresent(
        acknowledgements[triggerIndex++],
        'Expected Perps take-profit acknowledgement.',
      ),
    );
  }
  if (params.stopLoss !== undefined) {
    tpSl.stopLoss = placedOrderFrom(
      expectPresent(
        acknowledgements[triggerIndex],
        'Expected Perps stop-loss acknowledgement.',
      ),
    );
  }

  return { order: update.payload, tpSl };
}

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PlacePerpsPositionTpSlRequest =
  | {
      /** Perps instrument identifier whose current position should receive TP/SL protection. */
      instrumentId: number;
      /** Take-profit trigger to place for the current position. */
      takeProfit: PerpsPositionTpSlTrigger;
      /** Optional stop-loss trigger to place alongside the take-profit. */
      stopLoss?: PerpsPositionTpSlTrigger | PerpsPositionTrailingStop;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
    }
  | {
      /** Perps instrument identifier whose current position should receive TP/SL protection. */
      instrumentId: number;
      /** Optional take-profit trigger to place alongside the stop-loss. */
      takeProfit?: PerpsPositionTpSlTrigger;
      /** Stop-loss trigger to place for the current position. */
      stopLoss: PerpsPositionTpSlTrigger | PerpsPositionTrailingStop;
      /** Optional command expiration timestamp in milliseconds. */
      expiresAt?: number;
    };

const PerpsPositionTpSlRequiredPairSchema = z.union([
  z.object({
    takeProfit: PerpsPositionTpSlTriggerSchema,
    stopLoss: PerpsPositionStopLossSchema.optional(),
  }),
  z.object({
    takeProfit: PerpsPositionTpSlTriggerSchema.optional(),
    stopLoss: PerpsPositionStopLossSchema,
  }),
]);

const PlacePerpsPositionTpSlRequestSchema = z.intersection(
  PerpsPositionTpSlRequiredPairSchema,
  z.object({
    instrumentId: PerpsInstrumentIdSchema,
    expiresAt: z.number().int().positive().optional(),
  }),
) satisfies z.ZodType<PlacePerpsPositionTpSlRequest>;

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PlacePerpsPositionTpSlResult = {
  tpSl: PerpsPlacedTpSlOrders;
};

type PerpsPortfolioReader = {
  fetchPortfolio(): Promise<PerpsPortfolio>;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function placePerpsPositionTpSl(
  client: PerpsCommandExecutor & PerpsPortfolioReader,
  request: PlacePerpsPositionTpSlRequest,
): Promise<PlacePerpsPositionTpSlResult> {
  const params = parseUserInput(request, PlacePerpsPositionTpSlRequestSchema);
  const builderAttribution = client.builderAttribution;
  const buy = positionTpSlExitBuy(
    await client.fetchPortfolio(),
    params.instrumentId,
  );
  const orders: RawPerpsOrderInput[] = [];

  if (params.takeProfit !== undefined) {
    orders.push(
      toRawPerpsTpSlOrder({
        buy,
        instrumentId: params.instrumentId,
        kind: PerpsTpSlKind.TakeProfit,
        quantity: params.takeProfit.quantity ?? '0',
        builderAttribution,
        trigger: params.takeProfit,
      }),
    );
  }
  if (params.stopLoss !== undefined) {
    orders.push(
      toRawPerpsTpSlOrder({
        buy,
        instrumentId: params.instrumentId,
        kind: PerpsTpSlKind.StopLoss,
        quantity: params.stopLoss.quantity ?? '0',
        builderAttribution,
        trigger: params.stopLoss,
      }),
    );
  }

  const acknowledgements = await client.executeCommand(
    {
      op: ['createOrders', orders, PerpsTpSlScope.Position],
      expiresAt: params.expiresAt,
    },
    z.array(PerpsPostOrderAckSchema),
  );

  for (const acknowledgement of acknowledgements) {
    if (acknowledgement.status === 'err') {
      throw new RequestRejectedError(acknowledgement.error, { status: 200 });
    }
  }

  let triggerIndex = 0;
  const tpSl: PerpsPlacedTpSlOrders = {};
  if (params.takeProfit !== undefined) {
    tpSl.takeProfit = placedOrderFrom(
      expectPresent(
        acknowledgements[triggerIndex++],
        'Expected Perps take-profit acknowledgement.',
      ),
    );
  }
  if (params.stopLoss !== undefined) {
    tpSl.stopLoss = placedOrderFrom(
      expectPresent(
        acknowledgements[triggerIndex],
        'Expected Perps stop-loss acknowledgement.',
      ),
    );
  }

  return { tpSl };
}

const DEFAULT_PERPS_CANCEL_MAX_ATTEMPTS = 4;
const DEFAULT_PERPS_CANCEL_MAX_ELAPSED_MS = 2_000;
const PERPS_CANCEL_RETRY_BASE_DELAY_MS = 100;
const PERPS_CANCEL_RETRY_MAX_DELAY_MS = 1_000;

const PerpsCancelRetryOptionsSchema = z
  .object({
    maxAttempts: z
      .number()
      .int()
      .positive()
      .default(DEFAULT_PERPS_CANCEL_MAX_ATTEMPTS),
    maxElapsedMs: z
      .number()
      .int()
      .positive()
      .default(DEFAULT_PERPS_CANCEL_MAX_ELAPSED_MS),
  })
  .default({
    maxAttempts: DEFAULT_PERPS_CANCEL_MAX_ATTEMPTS,
    maxElapsedMs: DEFAULT_PERPS_CANCEL_MAX_ELAPSED_MS,
  }) satisfies z.ZodType<PerpsCancelRetryOptions>;

const PerpsCancelOptionsSchema = z.object({
  expiresAt: z.number().int().positive().optional(),
  retry: z.union([z.literal(false), PerpsCancelRetryOptionsSchema]).default({
    maxAttempts: DEFAULT_PERPS_CANCEL_MAX_ATTEMPTS,
    maxElapsedMs: DEFAULT_PERPS_CANCEL_MAX_ELAPSED_MS,
  }),
  signal: z
    .custom<AbortSignal>(
      (value) => value instanceof AbortSignal,
      'Expected an AbortSignal.',
    )
    .optional(),
}) satisfies z.ZodType<PerpsCancelOptions>;

/**
 * Bounds automatic retries for transient Perps cancellation rejections.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsCancelRetryOptions = {
  /** Maximum attempts per order, including the initial request. @defaultValue 4 */
  maxAttempts?: number;
  /**
   * Maximum elapsed time before starting a retry, in milliseconds. Retries
   * also stop at `expiresAt`, whichever limit is reached first.
   * @defaultValue 2_000
   */
  maxElapsedMs?: number;
};

/**
 * Shared options for Perps order cancellation.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type PerpsCancelOptions = {
  /**
   * Optional command expiration timestamp in milliseconds. Automatic retries
   * stop at this timestamp even when `maxElapsedMs` would allow more time.
   */
  expiresAt?: number;
  /** Automatic retry limits, or `false` to make only one attempt. */
  retry?: PerpsCancelRetryOptions | false;
  /**
   * Signal that prevents the first attempt when already aborted and stops
   * further retries after the current attempt settles. Does not cancel an
   * in-flight command or suppress its failure.
   */
  signal?: AbortSignal;
};

const CancelPerpsOrderRequestSchema = z.union([
  PerpsCancelOptionsSchema.extend({
    orderId: PerpsOrderIdSchema,
    clientOrderId: z.undefined().optional(),
  }),
  PerpsCancelOptionsSchema.extend({
    clientOrderId: PerpsClientOrderIdSchema,
    orderId: z.undefined().optional(),
  }),
]) satisfies z.ZodType<CancelPerpsOrderRequest>;

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type CancelPerpsOrderRequest = PerpsCancelOptions &
  (
    | {
        /** Order identifier to cancel. */
        orderId: number;
        clientOrderId?: never;
      }
    | {
        /** Caller-supplied idempotency identifier to cancel. */
        clientOrderId: string;
        orderId?: never;
      }
  );

/**
 * @remarks
 * First-attempt failures propagate unchanged. A later attempt failure throws
 * {@link PerpsCancelRetryError} with the last received results, the original
 * request positions retried in the failed attempt, and the original cause.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function cancelPerpsOrder(
  client: PerpsCommandExecutor,
  request: CancelPerpsOrderRequest,
): Promise<PerpsCancelOrderResult> {
  const params = parseUserInput(request, CancelPerpsOrderRequestSchema);
  const [result] =
    params.orderId !== undefined
      ? await cancelPerpsOrders(client, {
          orderIds: [params.orderId],
          expiresAt: params.expiresAt,
          retry: params.retry,
          signal: params.signal,
        })
      : await cancelPerpsOrders(client, {
          clientOrderIds: [params.clientOrderId],
          expiresAt: params.expiresAt,
          retry: params.retry,
          signal: params.signal,
        });
  return expectPresent(result, 'Expected Perps cancel order result.');
}

const CancelPerpsOrdersRequestSchema = z.union([
  PerpsCancelOptionsSchema.extend({
    orderIds: z.array(PerpsOrderIdSchema).min(1),
    clientOrderIds: z.undefined().optional(),
  }),
  PerpsCancelOptionsSchema.extend({
    clientOrderIds: z.array(PerpsClientOrderIdSchema).min(1),
    orderIds: z.undefined().optional(),
  }),
]) satisfies z.ZodType<CancelPerpsOrdersRequest>;

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type CancelPerpsOrdersRequest = PerpsCancelOptions &
  (
    | {
        /** Order identifiers to cancel. */
        orderIds: number[];
        clientOrderIds?: never;
      }
    | {
        /** Caller-supplied idempotency identifiers to cancel. */
        clientOrderIds: string[];
        orderIds?: never;
      }
  );

/**
 * @remarks
 * First-attempt failures propagate unchanged. A later attempt failure throws
 * {@link PerpsCancelRetryError} with the last received results, the original
 * request positions retried in the failed attempt, and the original cause.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function cancelPerpsOrders(
  client: PerpsCommandExecutor,
  request: CancelPerpsOrdersRequest,
): Promise<PerpsCancelOrderResult[]> {
  const params = parseUserInput(request, CancelPerpsOrdersRequestSchema);
  if (params.orderIds !== undefined) {
    return await retryPerpsOrderCancellations(
      params.orderIds,
      params,
      async (orderIds) =>
        await client.executeCommand(
          {
            op: ['cancelOrders', orderIds],
            expiresAt: params.expiresAt,
          },
          z.array(PerpsCancelOrderResultSchema),
        ),
    );
  }
  return await retryPerpsOrderCancellations(
    params.clientOrderIds,
    params,
    async (clientOrderIds) =>
      await client.executeCommand(
        {
          op: ['cancelOrdersCOID', clientOrderIds],
          expiresAt: params.expiresAt,
        },
        z.array(PerpsCancelOrderResultSchema),
      ),
  );
}

type ParsedPerpsCancelOptions = z.output<typeof PerpsCancelOptionsSchema>;

type PendingPerpsCancellation<TIdentifier> = {
  identifier: TIdentifier;
  resultIndex: number;
};

async function retryPerpsOrderCancellations<TIdentifier>(
  identifiers: TIdentifier[],
  options: ParsedPerpsCancelOptions,
  execute: (identifiers: TIdentifier[]) => Promise<PerpsCancelOrderResult[]>,
): Promise<PerpsCancelOrderResult[]> {
  const maxAttempts = options.retry === false ? 1 : options.retry.maxAttempts;
  const retryDeadline =
    options.retry === false
      ? Number.POSITIVE_INFINITY
      : Math.min(
          Date.now() + options.retry.maxElapsedMs,
          options.expiresAt ?? Number.POSITIVE_INFINITY,
        );
  const finalResults = new Array<PerpsCancelOrderResult | undefined>(
    identifiers.length,
  );
  let pending = identifiers.map((identifier, resultIndex) => ({
    identifier,
    resultIndex,
  }));
  let attempts = 0;

  assertPerpsCancelNotAborted(options.signal);
  while (pending.length > 0) {
    if (attempts > 0) {
      const remainingMs = retryDeadline - Date.now();
      const delayMs = perpsCancelRetryDelayMs(attempts);
      if (remainingMs <= 0 || delayMs >= remainingMs) break;
      const retry = await waitForPerpsCancelRetry(delayMs, options.signal);
      if (!retry || options.signal?.aborted || Date.now() >= retryDeadline)
        break;
    }

    let attemptResults: PerpsCancelOrderResult[];
    try {
      attemptResults = await execute(
        pending.map(({ identifier }) => identifier),
      );
      const requestRejection = perpsCancelRequestRejectionFrom(attemptResults);
      if (requestRejection !== undefined) {
        throw new RequestRejectedError(requestRejection, { status: 200 });
      }
      if (attemptResults.length !== pending.length) {
        throw new UnexpectedResponseError(
          'Perps cancel response did not include one result per requested order.',
        );
      }
    } catch (cause) {
      if (attempts === 0) throw cause;
      throw new PerpsCancelRetryError('Perps cancellation retry failed.', {
        cause,
        results: finalResults.map((result) =>
          expectPresent(result, 'Expected a previous Perps cancel result.'),
        ),
        pendingIndexes: pending.map(({ resultIndex }) => resultIndex),
      });
    }

    attempts += 1;
    const retryable: Array<PendingPerpsCancellation<TIdentifier>> = [];
    for (const [index, result] of attemptResults.entries()) {
      const target = expectPresent(
        pending[index],
        'Expected a pending Perps cancellation.',
      );
      finalResults[target.resultIndex] = result;
      if (
        attempts < maxAttempts &&
        result.status === 'err' &&
        result.error === PerpsKnownCancelOrderErrorCode.OrderInFlight
      ) {
        retryable.push(target);
      }
    }
    pending = retryable;
  }

  return finalResults.map((result) =>
    expectPresent(result, 'Expected a final Perps cancel result.'),
  );
}

function perpsCancelRequestRejectionFrom(
  results: PerpsCancelOrderResult[],
): string | undefined {
  const [result] = results;
  if (
    results.length !== 1 ||
    result?.status !== 'err' ||
    result.orderId !== undefined ||
    result.clientOrderId !== undefined
  ) {
    return undefined;
  }
  return result.error;
}

function perpsCancelRetryDelayMs(retryNumber: number): number {
  const maximumDelayMs = Math.min(
    PERPS_CANCEL_RETRY_BASE_DELAY_MS * 2 ** (retryNumber - 1),
    PERPS_CANCEL_RETRY_MAX_DELAY_MS,
  );
  return Math.random() * maximumDelayMs;
}

function waitForPerpsCancelRetry(
  delayMs: number,
  signal: AbortSignal | undefined,
): Promise<boolean> {
  if (signal?.aborted) return Promise.resolve(false);
  if (delayMs <= 0) {
    return Promise.resolve(true);
  }
  if (signal === undefined) {
    return new Promise((resolve) =>
      setNonBlockingTimeout(() => resolve(true), delayMs),
    );
  }

  const abortSignal = signal;
  return new Promise((resolve) => {
    const timer = setNonBlockingTimeout(() => {
      abortSignal.removeEventListener('abort', onAbort);
      resolve(true);
    }, delayMs);
    function onAbort() {
      clearTimeout(timer);
      resolve(false);
    }
    abortSignal.addEventListener('abort', onAbort, { once: true });
  });
}

function assertPerpsCancelNotAborted(signal: AbortSignal | undefined): void {
  if (signal?.aborted) {
    throw OperationAbortedError.fromReason(signal.reason);
  }
}

const CancelAllPerpsOrdersRequestSchema = z
  .object({
    instrumentId: PerpsInstrumentIdSchema.optional(),
    expiresAt: z.number().int().positive().optional(),
  })
  .default({}) satisfies z.ZodType<CancelAllPerpsOrdersRequest>;

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type CancelAllPerpsOrdersRequest = {
  /** Optional Perps instrument identifier to scope cancellation. */
  instrumentId?: number;
  /** Optional command expiration timestamp in milliseconds. */
  expiresAt?: number;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function cancelAllOrders(
  client: PerpsDeleteCommandExecutor,
  request?: CancelAllPerpsOrdersRequest,
): Promise<void> {
  const params = parseUserInput(request, CancelAllPerpsOrdersRequestSchema);
  const op = [
    'cancelAll',
    params.instrumentId === undefined ? [] : [params.instrumentId],
  ] as const satisfies PerpsSignedOp;
  await client.executeDeleteCommand({
    path: '/v1/trade/orders/all',
    op,
    responseSchema: PerpsCancelAllOrdersResponseSchema,
    expiresAt: params.expiresAt,
  });
}

const MINIMUM_AUTO_CANCEL_DELAY_MILLISECONDS = 5_000;

const ArmPerpsAutoCancelRequestSchema = z
  .object({
    cancelAt: z.number().int().positive(),
    expiresAt: z.number().int().positive().optional(),
  })
  .superRefine((params, context) => {
    const minimumCancelAt = Date.now() + MINIMUM_AUTO_CANCEL_DELAY_MILLISECONDS;

    if (params.cancelAt < minimumCancelAt) {
      context.addIssue({
        code: 'custom',
        message: 'cancelAt must be at least 5 seconds in the future.',
        path: ['cancelAt'],
      });
    }
  }) satisfies z.ZodType<ArmPerpsAutoCancelRequest>;

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type ArmPerpsAutoCancelRequest = {
  /**
   * Unix timestamp in milliseconds at which all open orders are cancelled.
   * Must be at least five seconds in the future.
   */
  cancelAt: number;
  /** Optional command expiration timestamp in milliseconds. */
  expiresAt?: number;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type ArmPerpsAutoCancelError =
  | AutoCancelDailyLimitError
  | RateLimitError
  | RequestRejectedError
  | SigningError
  | TransportError
  | UnexpectedResponseError
  | UserInputError;
/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export const ArmPerpsAutoCancelError = makeErrorGuard(
  AutoCancelDailyLimitError,
  RateLimitError,
  RequestRejectedError,
  SigningError,
  TransportError,
  UnexpectedResponseError,
  UserInputError,
);

// Rejection identifier reported by the API when arming exceeds the daily
// trigger limit. The rejection message is the identifier followed by request
// context in parentheses.
const AUTO_CANCEL_DAILY_LIMIT_REACHED = 'auto_cancel_daily_limit_reached';

/**
 * Arms the one-shot auto-cancel switch that cancels all open Perps orders at
 * the requested time. Arming again replaces the previous schedule.
 *
 * @throws {@link ArmPerpsAutoCancelError}
 * Thrown on failure.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function armPerpsAutoCancel(
  client: ServiceClient,
  signCommand: SignPerpsRestCommand,
  request: ArmPerpsAutoCancelRequest,
): Promise<void> {
  const params = parseUserInput(request, ArmPerpsAutoCancelRequestSchema);
  const op = ['autoCancel', [params.cancelAt]] as const satisfies PerpsSignedOp;
  const command = signCommand(op, params.expiresAt);

  await client
    .patch('/v1/trade/auto-cancel', {
      schema: PerpsAutoCancelResponseSchema,
      json: {
        ...command,
        op: toPerpsCommandBodyOp(op),
      },
    })
    .catch((error: unknown) => {
      throw error instanceof RequestRejectedError &&
        error.message.startsWith(`${AUTO_CANCEL_DAILY_LIMIT_REACHED} (`)
        ? new AutoCancelDailyLimitError(
            'Auto-cancel daily trigger limit reached.',
            { cause: error },
          )
        : error;
    });
}

const DisarmPerpsAutoCancelRequestSchema = z
  .object({
    expiresAt: z.number().int().positive().optional(),
  })
  .default({}) satisfies z.ZodType<DisarmPerpsAutoCancelRequest>;

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type DisarmPerpsAutoCancelRequest = {
  /** Optional command expiration timestamp in milliseconds. */
  expiresAt?: number;
};

/**
 * Disarms the auto-cancel schedule without triggering it. Disarming is
 * allowed even when the daily trigger limit has been reached.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function disarmPerpsAutoCancel(
  client: ServiceClient,
  signCommand: SignPerpsRestCommand,
  request?: DisarmPerpsAutoCancelRequest,
): Promise<void> {
  const params = parseUserInput(request, DisarmPerpsAutoCancelRequestSchema);
  const op = ['autoCancel', [0]] as const satisfies PerpsSignedOp;
  const command = signCommand(op, params.expiresAt);

  await client.patch('/v1/trade/auto-cancel', {
    schema: PerpsAutoCancelResponseSchema,
    json: {
      ...command,
      op: toPerpsCommandBodyOp(op),
    },
  });
}

const UpdatePerpsLeverageRequestSchema = z.object({
  instrumentId: PerpsInstrumentIdSchema,
  leverage: z.number().int().positive(),
  crossMargin: z.boolean(),
}) satisfies z.ZodType<UpdatePerpsLeverageRequest>;

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type UpdatePerpsLeverageRequest = {
  /** Perps instrument identifier whose leverage should be updated. */
  instrumentId: number;
  /** Target leverage multiplier. */
  leverage: number;
  /** Whether the instrument should use cross margin. */
  crossMargin: boolean;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type UpdatePerpsLeverageError =
  | RequestRejectedError
  | SigningError
  | TransportError
  | UserInputError;
/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export const UpdatePerpsLeverageError = makeErrorGuard(
  RequestRejectedError,
  SigningError,
  TransportError,
  UserInputError,
);

/**
 * Updates Perps leverage and margin mode for an instrument.
 *
 * @throws {@link UpdatePerpsLeverageError}
 * Thrown on failure.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function updatePerpsLeverage(
  client: PerpsCommandExecutor,
  request: UpdatePerpsLeverageRequest,
): Promise<PerpsUpdateLeverageResult> {
  const params = parseUserInput(request, UpdatePerpsLeverageRequestSchema);
  return await client.executeCommand(
    {
      op: [
        'updateLeverage',
        [params.instrumentId, params.leverage, params.crossMargin],
      ],
    },
    PerpsUpdateLeverageResultSchema,
  );
}

const UpdatePerpsLeveragesRequestSchema = z.object({
  updates: z
    .array(
      UpdatePerpsLeverageRequestSchema.extend({
        instrumentId: z.number().int().nonnegative().max(0xffff_ffff),
        leverage: z.number().int().positive().max(0xffff_ffff),
      }),
    )
    .min(1)
    .max(100)
    .superRefine((updates, context) => {
      const instrumentIds = new Set<number>();
      for (const [index, update] of updates.entries()) {
        if (instrumentIds.has(update.instrumentId)) {
          context.addIssue({
            code: 'custom',
            message: 'Expected each instrumentId to be unique',
            path: [index, 'instrumentId'],
          });
        }
        instrumentIds.add(update.instrumentId);
      }
    }),
}) satisfies z.ZodType<UpdatePerpsLeveragesRequest>;

/**
 * Request parameters for updating leverage and margin mode for one or more
 * Perps instruments.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type UpdatePerpsLeveragesRequest = {
  /** One to 100 updates with unique instrument identifiers. */
  updates: UpdatePerpsLeverageRequest[];
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type UpdatePerpsLeveragesError =
  | RequestRejectedError
  | SigningError
  | TransportError
  | UnexpectedResponseError
  | UserInputError;
/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export const UpdatePerpsLeveragesError = makeErrorGuard(
  RequestRejectedError,
  SigningError,
  TransportError,
  UnexpectedResponseError,
  UserInputError,
);

/**
 * Updates Perps leverage and margin mode for one or more instruments.
 *
 * @remarks
 * Updates are processed sequentially and are not atomic. Results preserve
 * request order. Per-instrument rejections, including `internal_error`, are
 * returned as data; `internal_error` may represent an unknown application
 * outcome for that instrument. A whole-request `internal_error` also has an
 * unknown application outcome; reconcile account state before retrying the
 * batch.
 *
 * @throws {@link UpdatePerpsLeveragesError}
 * Thrown when the complete request is rejected, cannot be sent, or returns inconsistent results.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function updatePerpsLeverages(
  client: PerpsCommandExecutor,
  request: UpdatePerpsLeveragesRequest,
): Promise<PerpsUpdateLeverageBatchResult[]> {
  const params = parseUserInput(request, UpdatePerpsLeveragesRequestSchema);
  const results = await client.executeCommand(
    {
      op: [
        'updateLeverages',
        params.updates.map((update) => [
          update.instrumentId,
          update.leverage,
          update.crossMargin,
        ]),
      ],
    },
    z.array(PerpsUpdateLeverageBatchResultSchema),
  );
  if (
    results.length !== params.updates.length ||
    results.some(
      (result, index) =>
        result.instrumentId !== params.updates[index]?.instrumentId,
    )
  ) {
    throw new UnexpectedResponseError(
      'Perps batch leverage results did not match the requested instruments.',
    );
  }
  return results;
}

const UpdatePerpsMarginRequestSchema = z.object({
  instrumentId: PerpsInstrumentIdSchema,
  amount: PerpsDecimalInputSchema,
}) satisfies z.ZodType<UpdatePerpsMarginRequest>;

/**
 * Request parameters for adjusting isolated margin on a Perps position.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type UpdatePerpsMarginRequest = {
  /** Perps instrument identifier whose isolated margin should be adjusted. */
  instrumentId: number;
  /** Margin adjustment. Positive values add margin; negative values remove it. */
  amount: PerpsDecimalInput;
};

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export type UpdatePerpsMarginError =
  | RequestRejectedError
  | SigningError
  | TransportError
  | UserInputError;
/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export const UpdatePerpsMarginError = makeErrorGuard(
  RequestRejectedError,
  SigningError,
  TransportError,
  UserInputError,
);

/**
 * Adjusts isolated margin for an instrument position.
 *
 * @throws {@link UpdatePerpsMarginError}
 * Thrown on failure.
 *
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export async function updatePerpsMargin(
  client: PerpsCommandExecutor,
  request: UpdatePerpsMarginRequest,
): Promise<void> {
  const params = parseUserInput(request, UpdatePerpsMarginRequestSchema);
  const amount = toDecimalString(params.amount);
  const ack = await client.executeCommand(
    { op: ['updateMargin', [params.instrumentId, amount]] },
    PerpsCommandAckSchema,
  );
  if (ack.status === 'err') {
    throw new RequestRejectedError(ack.error, { status: 200 });
  }
}

function randomClientOrderId(): PerpsClientOrderId {
  const bytes = globalThis.crypto.getRandomValues(new Uint8Array(16));
  return PerpsClientOrderIdSchema.parse(
    Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join(''),
  );
}

function isOrderUpdateFor(clientOrderId: PerpsClientOrderId) {
  return (event: PerpsSessionEvent): event is PerpsOrderUpdateEvent =>
    event.type === 'order' && event.payload.clientOrderId === clientOrderId;
}

function placedOrderFrom(
  acknowledgement: PerpsPostOrderAck,
): PerpsPlacedTpSlOrder {
  if (acknowledgement.status === 'err') {
    throw new RequestRejectedError(acknowledgement.error, { status: 200 });
  }

  return { orderId: acknowledgement.orderId };
}

function positionTpSlExitBuy(
  portfolio: PerpsPortfolio,
  instrumentId: PerpsInstrumentId,
): boolean {
  const position = portfolio.positions.find(
    (item) => item.instrumentId === instrumentId,
  );
  const sign = position === undefined ? 0 : decimalSign(position.size);

  if (sign === 0) {
    throw new UserInputError(
      `No open Perps position for instrument ${instrumentId}.`,
    );
  }

  return sign < 0;
}

function decimalSign(value: string): -1 | 0 | 1 {
  const trimmed = value.trim();
  const digits = trimmed.replace(/^[+-]/, '').replace('.', '');
  if (/^0*$/.test(digits)) return 0;
  return trimmed.startsWith('-') ? -1 : 1;
}

type RawPerpsOrderInput = readonly [
  PerpsInstrumentId,
  boolean,
  string | undefined,
  string,
  PerpsTimeInForce | undefined,
  boolean,
  true | undefined,
  string | undefined,
  RawPerpsTpSlTriggerInput | undefined,
  number | undefined,
  readonly [string, string] | undefined,
];

type RawPerpsTpSlTriggerInput = readonly [
  boolean | undefined,
  string | undefined,
  PerpsTpSlKind,
  number?,
  string?,
];

function toRawPerpsOrder(
  order: z.output<typeof PerpsOrderRequestSchema>,
  builderAttribution: PerpsBuilderTermsInput | undefined,
): RawPerpsOrderInput {
  return [
    order.instrumentId,
    order.side === OrderSide.BUY,
    order.price === undefined ? undefined : toDecimalString(order.price),
    toDecimalString(order.quantity),
    order.timeInForce,
    order.postOnly ?? false,
    order.reduceOnly === true ? true : undefined,
    order.clientOrderId,
    undefined,
    order.gtdExpiry,
    builderAttribution === undefined
      ? undefined
      : [builderAttribution.builderAddress, builderAttribution.feeRate],
  ];
}

function toRawPerpsTpSlOrder(request: {
  buy: boolean;
  instrumentId: PerpsInstrumentId;
  kind: PerpsTpSlKind;
  quantity: string;
  builderAttribution?: PerpsBuilderTermsInput;
  trigger: z.output<typeof PerpsStopLossSchema>;
}): RawPerpsOrderInput {
  return [
    request.instrumentId,
    request.buy,
    request.trigger.limitPrice === undefined
      ? undefined
      : toDecimalString(request.trigger.limitPrice),
    request.quantity,
    undefined,
    false,
    true,
    undefined,
    request.trigger.trailingBps === undefined
      ? [
          request.trigger.limitPrice === undefined ? true : undefined,
          toDecimalString(request.trigger.triggerPrice),
          request.kind,
        ]
      : [
          true,
          undefined,
          request.kind,
          request.trigger.trailingBps,
          request.trigger.activationPrice === undefined
            ? undefined
            : toDecimalString(request.trigger.activationPrice),
        ],
    undefined,
    request.builderAttribution == null
      ? undefined
      : [
          request.builderAttribution.builderAddress,
          request.builderAttribution.feeRate,
        ],
  ];
}

/**
 * @experimental This API may change in a breaking way in any release, including patch releases.
 */
export function toPerpsCommandBodyOp(op: PerpsSignedOp) {
  const [type, args, group] = op;
  switch (type) {
    case 'createOrders':
      return withOptionalGroup(
        {
          args: (args as RawPerpsOrderInput[]).map(toPerpsOrderBody),
          type,
        },
        group,
      );
    case 'cancelOrders':
    case 'cancelOrdersCOID':
      return { type, args };
    case 'autoCancel': {
      const [time] = args as readonly [number];
      return { type, args: { time } };
    }
    case 'cancelAll': {
      const [instrumentId] = args as readonly [PerpsInstrumentId | undefined];
      return {
        type,
        args: instrumentId === undefined ? {} : { iid: instrumentId },
      };
    }
    case 'updateLeverage': {
      const [instrumentId, leverage, crossMargin] = args as readonly [
        PerpsInstrumentId,
        number,
        boolean,
      ];
      return {
        type,
        args: {
          cross: crossMargin,
          iid: instrumentId,
          lev: leverage,
        },
      };
    }
    case 'updateLeverages': {
      const updates = args as ReadonlyArray<
        readonly [PerpsInstrumentId, number, boolean]
      >;
      return {
        type,
        args: updates.map(([instrumentId, leverage, crossMargin]) => ({
          cross: crossMargin,
          iid: instrumentId,
          lev: leverage,
        })),
      };
    }
    case 'updateMargin': {
      const [instrumentId, amount] = args as readonly [
        PerpsInstrumentId,
        string,
      ];
      return {
        type,
        args: {
          amt: amount,
          iid: instrumentId,
        },
      };
    }
    default:
      invariant(false, `Unsupported Perps command: ${String(type)}`);
  }
}

function toPerpsOrderBody(order: RawPerpsOrderInput) {
  const body: Record<string, unknown> = {
    iid: order[0],
    buy: order[1],
    po: order[5],
    qty: order[3],
  };
  if (order[4] !== undefined) body.tif = order[4];
  if (order[6]) body.ro = order[6];
  if (order[2] !== undefined) body.p = order[2];
  if (order[7] !== undefined) body.c = order[7];
  if (order[8] !== undefined) body.tr = toPerpsTpSlTriggerBody(order[8]);
  if (order[9] !== undefined) body.gtd_expiry = order[9];
  if (order[10] !== undefined) {
    body.builder = { address: order[10][0], fee_rate: order[10][1] };
  }
  return body;
}

function toPerpsTpSlTriggerBody(trigger: RawPerpsTpSlTriggerInput) {
  const body: Record<string, unknown> = {
    tpsl: trigger[2],
  };
  if (trigger[1] !== undefined) body.trp = trigger[1];
  if (trigger[3] !== undefined) body.trail_bps = trigger[3];
  if (trigger[4] !== undefined) body.act = trigger[4];
  if (trigger[0] !== undefined) body.market = trigger[0];
  return body;
}

function withOptionalGroup(
  body: Record<string, unknown>,
  group: unknown,
): Record<string, unknown> {
  if (group !== undefined) body.grp = group;
  return body;
}
