import type { ApiKeyCreds } from '@polymarket/bindings/clob';
import type { PriceEvent } from '@polymarket/bindings/subscriptions';
import type {
  EventForSubscriptionSpec,
  PriceSubscription,
  SubscriptionHandle,
} from '../../actions/subscriptions';
import type { WebSocketSubscriptionManager } from '../types';
import { SocketPool } from './pool';

export type { SubscribeError } from '../../actions/subscriptions';

export type RealtimeWebSocketManagerOptions = {
  url: string;
  headers?: Record<string, string>;
  credentials: ApiKeyCreds;
};

/** @internal Manages authenticated realtime prices across shared connections. */
export class RealtimeWebSocketManager
  implements WebSocketSubscriptionManager<PriceSubscription, PriceEvent>
{
  readonly #pool: SocketPool;

  constructor(options: RealtimeWebSocketManagerOptions) {
    this.#pool = new SocketPool(options);
  }

  /**
   * Starts a price subscription and awaits server acceptance.
   * @throws {@link SubscribeError} When input is invalid or the subscription fails.
   */
  async subscribe<const TSpec extends PriceSubscription>(
    spec: TSpec,
  ): Promise<SubscriptionHandle<EventForSubscriptionSpec<TSpec>>> {
    return this.#pool.subscribe(spec) as Promise<
      SubscriptionHandle<EventForSubscriptionSpec<TSpec>>
    >;
  }

  /** Closes every active price subscription and shared connection. */
  async close(): Promise<void> {
    await this.#pool.close();
  }
}
