import { afterEach, describe, expect, vi } from 'vitest';
import type { SubscriptionHandle } from '../../src/actions/subscriptions';
import { UserInputError } from '../../src/errors';
import { it, runMeteredTests } from './fixtures';

type SentOperation = {
  op?: string;
  subscriptions?: { channel: string; filter: object }[];
};
const NativeWebSocket = globalThis.WebSocket;
class ObservedWebSocket extends NativeWebSocket {
  static connections: ObservedWebSocket[] = [];
  readonly operations: SentOperation[] = [];
  messages = 0;
  constructor(url: string | URL, protocols?: string | string[]) {
    super(url, protocols);
    ObservedWebSocket.connections.push(this);
    this.addEventListener('message', () => this.messages++);
  }
  override send(data: string | Blob | BufferSource): void {
    if (typeof data === 'string') {
      const { op, subscriptions } = JSON.parse(data) as SentOperation;
      // Never retain authentication payloads in diagnostics.
      this.operations.push({ op, subscriptions });
    }
    super.send(data);
  }
}

async function first<T>(
  handle: SubscriptionHandle<T>,
  predicate: (event: T) => boolean,
): Promise<T> {
  const timeout = setTimeout(() => {
    void handle.close();
  }, 15_000);
  try {
    for await (const event of handle) if (predicate(event)) return event;
    throw new Error('No matching realtime event within 15 seconds.');
  } finally {
    clearTimeout(timeout);
    await handle.close();
  }
}

describe.runIf(runMeteredTests)('realtime price transport', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    ObservedWebSocket.connections = [];
  });

  it('discards buffered prices when closed before iteration starts', async ({
    secureClientWithDepositWallet: client,
  }) => {
    vi.stubGlobal('WebSocket', ObservedWebSocket);
    try {
      const handle = await client.subscribe([
        { topic: 'prices.crypto', symbols: ['btcusd'] },
      ]);
      await expect
        .poll(() => ObservedWebSocket.connections[0]?.messages ?? 0)
        .toBeGreaterThanOrEqual(3);
      await handle.close();
      const events = [];
      for await (const event of handle) events.push(event);
      expect(events).toEqual([]);
    } finally {
      await client.closeSubscriptions();
    }
  });

  it('delivers each update once for duplicate canonical symbols', async ({
    secureClientWithDepositWallet: client,
  }) => {
    const handle = await client.subscribe([
      { topic: 'prices.crypto', symbols: ['btcusd', 'btcusd'] },
    ]);
    const sequences: (number | undefined)[] = [];
    const timer = setTimeout(() => {
      void handle.close();
    }, 15_000);
    try {
      for await (const event of handle) {
        if (event.type !== 'update') continue;
        sequences.push(event.seq);
        if (sequences.length === 2) break;
      }
      expect(sequences).toHaveLength(2);
      expect(sequences[0]).not.toBe(sequences[1]);
    } finally {
      clearTimeout(timer);
      await client.closeSubscriptions();
    }
  });

  it('authenticates, shares keys, batches filters and grows beyond 64 keys', async ({
    secureClientWithDepositWallet: client,
  }) => {
    vi.stubGlobal('WebSocket', ObservedWebSocket);
    try {
      const handles = await Promise.all(
        Array.from({ length: 70 }, (_, index) =>
          client.subscribe([
            { topic: 'prices.crypto', symbols: [`asset${index}usd`] },
          ]),
        ),
      );
      expect(ObservedWebSocket.connections).toHaveLength(2);
      for (const socket of ObservedWebSocket.connections)
        expect(socket.operations[0]?.op).toBe('auth');
      expect(
        ObservedWebSocket.connections
          .flatMap((socket) => socket.operations)
          .filter((op) => op.op === 'subscribe')
          .map((op) => op.subscriptions?.length)
          .sort(),
      ).toEqual([6, 64]);
      const duplicate = await client.subscribe([
        { topic: 'prices.crypto', symbols: ['asset0usd'] },
      ]);
      expect(ObservedWebSocket.connections).toHaveLength(2);
      await duplicate.close();
      expect(
        ObservedWebSocket.connections[0]?.operations.filter(
          (op) => op.op === 'unsubscribe',
        ),
      ).toHaveLength(0);
      await Promise.all(handles.slice(1).map((handle) => handle.close()));
      await expect
        .poll(
          () =>
            ObservedWebSocket.connections.filter(
              (socket) => socket.readyState === NativeWebSocket.OPEN,
            ).length,
        )
        .toBe(1);
      await handles[0]?.close();
    } finally {
      await client.closeSubscriptions();
    }
  });

  it('delivers price history and updates with sources and connection-local sequences', async ({
    secureClientWithDepositWallet: client,
  }) => {
    try {
      const specs = [
        { topic: 'prices.crypto', symbols: ['btcusd', 'btcusd', 'ethusd'] },
        {
          topic: 'prices.crypto.twap',
          symbols: ['btcusd'],
        },
        { topic: 'prices.equity', symbol: 'aapl' },
      ] as const;
      // Keep sequence assertions below the 64-filter connection limit. Larger
      // subscriptions span sockets whose independent sequences may interleave.
      await Promise.all(
        specs.map(async (spec) => {
          for (const type of ['subscribe', 'update'] as const) {
            const event = await first(
              await client.subscribe([spec]),
              (event) => event.type === type,
            );
            expect(event.topic).toBe(spec.topic);
            expect(event.seq).toBeGreaterThan(0);
            expect(typeof event.payload.source).toBe('string');
            expect(event.payload.source).not.toBe('');
            if (event.type === 'update')
              expect(typeof event.payload.value).toBe('string');
            if ('windowSeconds' in event.payload) {
              expect(event.payload.windowSeconds).toBe(60);
              expect(event.payload.symbol).toBe('btcusd');
            }
          }
        }),
      );
    } finally {
      await client.closeSubscriptions();
    }
  });

  it('delivers equity TWAP history and updates in the pair quote currency', async ({
    secureClientWithDepositWallet: client,
  }) => {
    try {
      for (const type of ['subscribe', 'update'] as const) {
        const event = await first(
          await client.subscribe([
            {
              topic: 'prices.equity.twap',
              symbol: 'USDJPY',
            },
          ]),
          (event) => event.type === type,
        );
        expect(event.topic).toBe('prices.equity.twap');
        expect(event.payload.symbol).toBe('usdjpy');
        expect(event.payload.windowSeconds).toBe(60);
        expect(typeof event.payload.source).toBe('string');
        expect(event.payload.source).not.toBe('');
        if (event.type === 'update')
          expect(typeof event.payload.value).toBe('string');
      }
    } finally {
      await client.closeSubscriptions();
    }
  });

  it('keeps live prices flowing across 100 filters on shared connections', async ({
    secureClientWithDepositWallet: client,
  }) => {
    vi.stubGlobal('WebSocket', ObservedWebSocket);
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      // Known feeds prove delivery; additional keys exercise connection capacity.
      const stream = await client.subscribe([
        {
          topic: 'prices.crypto',
          symbols: [
            'btcusd',
            'ethusd',
            ...Array.from({ length: 98 }, (_, index) => `asset${index}usd`),
          ],
        },
      ]);
      expect(ObservedWebSocket.connections).toHaveLength(2);
      // Do not assert global sequence ordering: this stream merges two sockets.
      let updates = 0;
      let intervalCompleted = false;
      timer = setTimeout(() => {
        intervalCompleted = true;
        void stream.close();
      }, 15_000);
      for await (const event of stream) {
        if (event.type === 'update') {
          expect(['btcusd', 'ethusd']).toContain(event.payload.symbol);
          updates++;
        }
      }
      expect(intervalCompleted).toBe(true);
      expect(updates).toBeGreaterThan(1);
      expect(ObservedWebSocket.connections).toHaveLength(2);
    } finally {
      clearTimeout(timer);
      await client.closeSubscriptions();
    }
  });

  it('delivers 60-second TWAP and equity snapshot barriers', async ({
    secureClientWithDepositWallet: client,
  }) => {
    try {
      const event = await first(
        await client.subscribe([
          {
            topic: 'prices.crypto.twap',
            symbols: ['btcusd'],
          },
        ]),
        (event) => event.type === 'subscribe',
      );
      expect(event.type).toBe('subscribe');
      expect(event.payload.windowSeconds).toBe(60);
      const equity = await first(
        await client.subscribe([{ topic: 'prices.equity', symbol: 'aapl' }]),
        (event) => event.type === 'subscribe',
      );
      expect(equity.type).toBe('subscribe');
    } finally {
      await client.closeSubscriptions();
    }
  });

  it('seeds a joining handle with current shared history', async ({
    secureClientWithDepositWallet: client,
  }) => {
    vi.stubGlobal('WebSocket', ObservedWebSocket);
    const initial = await client.subscribe([
      { topic: 'prices.crypto', symbols: ['btcusd'] },
    ]);
    const latest = Promise.withResolvers<number>();
    const consuming = (async () => {
      for await (const event of initial)
        if (event.type === 'update') latest.resolve(event.payload.timestamp);
    })();
    const timer = setTimeout(
      () => latest.reject(new Error('No live price arrived.')),
      15_000,
    );
    try {
      const timestamp = await latest.promise;
      const snapshot = await first(
        await client.subscribe([
          { topic: 'prices.crypto', symbols: ['btcusd'] },
        ]),
        (event) => event.type === 'subscribe',
      );
      expect(snapshot.type).toBe('subscribe');
      if (snapshot.type === 'subscribe')
        expect(snapshot.payload.data.at(-1)?.timestamp).toBeGreaterThanOrEqual(
          timestamp,
        );
      expect(
        ObservedWebSocket.connections
          .flatMap((socket) => socket.operations)
          .filter((op) => op.op === 'subscribe'),
      ).toHaveLength(1);
    } finally {
      clearTimeout(timer);
      await client.closeSubscriptions();
      await consuming;
    }
  });

  it('rejects missing filters and public access before opening a socket', async ({
    publicClient,
    secureClientWithDepositWallet: client,
  }) => {
    vi.stubGlobal('WebSocket', ObservedWebSocket);
    await expect(
      client.subscribe([{ topic: 'prices.crypto', symbols: [] }]),
    ).rejects.toBeInstanceOf(UserInputError);
    await expect(
      client.subscribe([{ topic: 'prices.crypto' } as never]),
    ).rejects.toBeInstanceOf(UserInputError);
    await expect(
      publicClient.subscribe([
        // @ts-expect-error Price subscriptions require a secure client.
        { topic: 'prices.crypto', symbols: ['btcusd'] },
      ]),
    ).rejects.toBeInstanceOf(UserInputError);
    expect(ObservedWebSocket.connections).toHaveLength(0);
  });

  it('rejects invalid filters before opening a mixed batch', async ({
    secureClientWithDepositWallet: client,
  }) => {
    vi.stubGlobal('WebSocket', ObservedWebSocket);
    const invalid = [
      { topic: 'prices.crypto', symbols: [] },
      { topic: 'prices.crypto.twap', symbols: ['btcusd'], windowSeconds: 30 },
      { topic: 'prices.crypto.twap', symbols: ['/'] },
      ...['prices.crypto', 'prices.crypto.twap'].flatMap((topic) =>
        ['btc/usd', 'btcusdt', 'BTCUSD', ' btcusd '].map((symbol) => ({
          topic,
          symbols: [symbol],
        })),
      ),
      { topic: 'prices.crypto', symbols: ['btcusd'], includeSnapshot: false },
      { topic: 'prices.equity.twap', symbol: 'usdjpy', windowSeconds: 30 },
      { topic: 'prices.equity.twap', symbol: 'usdjpy', types: ['update'] },
    ];
    try {
      for (const spec of invalid) {
        await expect(
          client.subscribe([
            { topic: 'prices.crypto', symbols: ['btcusd'] },
            spec as never,
          ]),
        ).rejects.toBeInstanceOf(UserInputError);
      }
      expect(ObservedWebSocket.connections).toHaveLength(0);
    } finally {
      await client.closeSubscriptions();
    }
  });
});
